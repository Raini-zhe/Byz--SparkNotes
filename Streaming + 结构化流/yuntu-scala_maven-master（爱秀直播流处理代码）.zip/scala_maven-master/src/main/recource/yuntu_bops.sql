/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50635
Source Host           : localhost:3306
Source Database       : yuntu_bops

Target Server Type    : MYSQL
Target Server Version : 50635
File Encoding         : 65001

Date: 2017-07-14 18:38:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for app_conf
-- ----------------------------
DROP TABLE IF EXISTS `app_conf`;
CREATE TABLE `app_conf` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `app` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_on` datetime DEFAULT NULL,
  `gmt_off` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `key` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(2048) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_key` (`app`,`key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for app_plugin
-- ----------------------------
DROP TABLE IF EXISTS `app_plugin`;
CREATE TABLE `app_plugin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `app` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `plugin_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `in_use` int(1) DEFAULT NULL,
  `remark` varchar(512) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `app_name` (`app`,`plugin_name`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for app_probe_app
-- ----------------------------
DROP TABLE IF EXISTS `app_probe_app`;
CREATE TABLE `app_probe_app` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) DEFAULT NULL,
  `uid` varchar(14) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for app_probe_app_def
-- ----------------------------
DROP TABLE IF EXISTS `app_probe_app_def`;
CREATE TABLE `app_probe_app_def` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) DEFAULT NULL,
  `package_name` varchar(256) DEFAULT NULL,
  `app_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for app_probe_user
-- ----------------------------
DROP TABLE IF EXISTS `app_probe_user`;
CREATE TABLE `app_probe_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(14) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `market_id` varchar(16) DEFAULT NULL,
  `version` varchar(8) DEFAULT NULL,
  `isp` varchar(256) DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for async_task
-- ----------------------------
DROP TABLE IF EXISTS `async_task`;
CREATE TABLE `async_task` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_type` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_key` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `params` varchar(2048) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `retries` int(11) DEFAULT NULL,
  `errors` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_run` datetime DEFAULT NULL,
  `gmt_finish` datetime DEFAULT NULL,
  `task_result` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_group_key` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_schedule` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gmt_schedule` (`gmt_schedule`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for biz_conf
-- ----------------------------
DROP TABLE IF EXISTS `biz_conf`;
CREATE TABLE `biz_conf` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conf_group` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `conf_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `conf_value` text COLLATE utf8_unicode_ci,
  `parent_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_code` (`conf_group`,`conf_code`)
) ENGINE=InnoDB AUTO_INCREMENT=625 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for campaigns
-- ----------------------------
DROP TABLE IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `index` int(11) DEFAULT NULL,
  `gmt_start` datetime DEFAULT NULL,
  `gmt_end` datetime DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `channel` int(11) DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app` varchar(128) COLLATE utf8_unicode_ci DEFAULT 'yuntutv',
  `delete_flag` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gmt_modify` (`gmt_modify`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=471 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for campaign_items
-- ----------------------------
DROP TABLE IF EXISTS `campaign_items`;
CREATE TABLE `campaign_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint(20) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `conf_group` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delete_flag` int(1) DEFAULT NULL,
  `unique_url` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gmt_modify` (`gmt_modify`) USING BTREE,
  KEY `unique_url` (`unique_url`(100)) USING BTREE,
  KEY `IDX_PA_CO_IN` (`parent_id`,`conf_group`,`index`)
) ENGINE=InnoDB AUTO_INCREMENT=305603 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for channel
-- ----------------------------
DROP TABLE IF EXISTS `channel`;
CREATE TABLE `channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `channel_code` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `channel_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `conf_group` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `channel_code` (`channel_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1389 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for events
-- ----------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `event_type` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app` varchar(128) COLLATE utf8_unicode_ci DEFAULT 'yuntutv',
  `result_status` int(11) DEFAULT NULL,
  `source_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gmt_modify` (`gmt_modify`),
  KEY `source_id` (`source_id`) USING HASH,
  KEY `start_time` (`start_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for event_winner
-- ----------------------------
DROP TABLE IF EXISTS `event_winner`;
CREATE TABLE `event_winner` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `icon` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for kafka_offsets
-- ----------------------------
DROP TABLE IF EXISTS `kafka_offsets`;
CREATE TABLE `kafka_offsets` (
  `topic` varchar(32) DEFAULT NULL,
  `part` tinyint(2) DEFAULT NULL,
  `offset` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_active_channel_user
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_active_channel_user`;
CREATE TABLE `loveshow_active_channel_user` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `active_users` int(10) NOT NULL,
  `channel` varchar(32) DEFAULT NULL,
  `term` int(11) DEFAULT NULL,
  `active_recharge_users` int(10) DEFAULT NULL,
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_active_vest_user
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_active_vest_user`;
CREATE TABLE `loveshow_active_vest_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active_users` int(10) NOT NULL,
  `vest` varchar(32) DEFAULT NULL,
  `term` tinyint(2) DEFAULT NULL,
  `active_recharge_users` int(10) DEFAULT NULL,
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_anchor_flow
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_anchor_flow`;
CREATE TABLE `loveshow_anchor_flow` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `anchor_id` int(10) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `etime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ptime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `location` varchar(32) DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `isp` varchar(32) DEFAULT NULL,
  `term` tinyint(2) DEFAULT NULL,
  `model` varchar(32) DEFAULT NULL,
  `device_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_anchor_live_peak
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_anchor_live_peak`;
CREATE TABLE `loveshow_anchor_live_peak` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `room_id` int(20) NOT NULL,
  `uid` int(10) NOT NULL,
  `ctime` varchar(30) NOT NULL,
  `etime` varchar(30) NOT NULL,
  `peak_time` varchar(30) NOT NULL,
  `peak_users` int(11) NOT NULL,
  `nick_name` varchar(32) DEFAULT NULL,
  `tag` varchar(128) DEFAULT NULL,
  `identification` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4682 DEFAULT CHARSET=utf8mb4 COMMENT='直播间单次开播过程中房间最高同时在线人数';

-- ----------------------------
-- Table structure for loveshow_anchor_quality
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_anchor_quality`;
CREATE TABLE `loveshow_anchor_quality` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `rid` int(20) DEFAULT NULL,
  `fans` int(11) DEFAULT NULL,
  `beans` int(11) DEFAULT NULL,
  `durations` int(11) NOT NULL,
  `ctag` varchar(32) DEFAULT NULL,
  `cidentification` varchar(100) DEFAULT NULL,
  `percent25` int(11) DEFAULT NULL,
  `percent50` int(11) DEFAULT NULL,
  `percent75` int(11) DEFAULT NULL,
  `stats_date` varchar(20) DEFAULT NULL,
  `nick_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1993 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_card_activity
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_card_activity`;
CREATE TABLE `loveshow_card_activity` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `type` int(10) NOT NULL COMMENT '100:奖励2500爱钻，200:奖励5000爱钻，500:奖励12500爱钻，',
  `live_anchors` int(10) NOT NULL COMMENT '开播主播数',
  `live_times` int(10) NOT NULL COMMENT '开播次数',
  `duration` int(10) NOT NULL COMMENT '开播持续时间',
  `avg_duration` int(10) DEFAULT NULL COMMENT '人均开播时间',
  `recv_diamonds` int(10) NOT NULL COMMENT '收到爱钻',
  `recv_anchors` int(10) NOT NULL COMMENT '收礼主播数',
  `avg_recv_diamonds` int(10) DEFAULT NULL COMMENT '平均收礼爱钻数',
  `register_user` int(10) NOT NULL COMMENT '注册主播数',
  `reward` int(10) NOT NULL COMMENT '奖励',
  `finish_anchors` int(10) NOT NULL COMMENT '完成任务主播数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='卡片活动';

-- ----------------------------
-- Table structure for loveshow_channel_new_user
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_channel_new_user`;
CREATE TABLE `loveshow_channel_new_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `channel` varchar(32) NOT NULL COMMENT '渠道',
  `new_register_users` int(10) DEFAULT '0' COMMENT '新增用户数',
  `new_recharge_users` int(10) DEFAULT '0' COMMENT '新增充值用户',
  `new_recharge_amounts` int(10) DEFAULT '0' COMMENT '新充值用户充值金额',
  `new_register_recharge_users` int(10) DEFAULT '0' COMMENT '当天注册充值用户',
  `old_register_recharge_users` int(10) DEFAULT '0' COMMENT '以往注册第一次充值用户',
  `new_register_users_recharge_amounts` int(10) DEFAULT '0' COMMENT '新注册用户第一次充值总金额',
  `old_register_user_recharge_amounts` int(10) DEFAULT '0' COMMENT '以往注册用户第一次充值金额',
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=533 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_channel_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_channel_recharge`;
CREATE TABLE `loveshow_channel_recharge` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `channel` varchar(32) NOT NULL COMMENT '渠道',
  `term` tinyint(2) NOT NULL COMMENT '0:安卓1：ios',
  `stats_date` varchar(20) NOT NULL,
  `recharge_users` int(10) DEFAULT '0' COMMENT '当日注册用户数',
  `recharge_amounts` int(10) DEFAULT '0' COMMENT '当日充值总金额',
  `recharge_diamonds` int(10) DEFAULT '0' COMMENT '当日充值产生爱钻',
  `recharge_times` int(10) DEFAULT '0' COMMENT '当日充值总次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_channel_user_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_channel_user_recharge`;
CREATE TABLE `loveshow_channel_user_recharge` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `channel` varchar(32) NOT NULL COMMENT '渠道',
  `new_register_users` int(10) DEFAULT '0' COMMENT '新增用户数',
  `new_recharge_users` int(10) DEFAULT '0' COMMENT '新增充值用户',
  `new_recharge_amounts` int(10) DEFAULT '0' COMMENT '新充值用户充值金额',
  `new_register_recharge_users` int(10) DEFAULT '0' COMMENT '当天注册充值用户',
  `old_register_recharge_users` int(10) DEFAULT '0' COMMENT '以往注册第一次充值用户',
  `new_register_users_recharge_amounts` int(10) DEFAULT '0' COMMENT '新注册用户第一次充值总金额',
  `old_register_user_recharge_amounts` int(10) DEFAULT '0' COMMENT '以往注册用户第一次充值金额',
  `stats_date` varchar(20) NOT NULL,
  `recharge_users` int(10) DEFAULT '0' COMMENT '当日注册用户数',
  `recharge_amounts` int(10) DEFAULT '0' COMMENT '当日充值总金额',
  `recharge_diamonds` int(10) DEFAULT '0' COMMENT '当日充值产生爱钻',
  `recharge_times` int(10) DEFAULT '0' COMMENT '当日充值总次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=381 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_first_recharge_time
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_first_recharge_time`;
CREATE TABLE `loveshow_first_recharge_time` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `first_recharge_time` varchar(32) DEFAULT NULL,
  `recharge_users` int(10) NOT NULL,
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COMMENT='用户首次充值时间分布';

-- ----------------------------
-- Table structure for loveshow_gift_consume_snapshots
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_gift_consume_snapshots`;
CREATE TABLE `loveshow_gift_consume_snapshots` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `gift_price` int(10) DEFAULT NULL,
  `gift_name` varchar(30) DEFAULT NULL,
  `gift_tag` varchar(30) DEFAULT NULL,
  `scope` int(2) NOT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `gid` int(10) DEFAULT NULL,
  `consume_diamonds` int(10) DEFAULT NULL,
  `total_users` int(10) NOT NULL,
  `cnt` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158204 DEFAULT CHARSET=utf8mb4 COMMENT='用户礼物消耗快照';

-- ----------------------------
-- Table structure for loveshow_interval_gift
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_interval_gift`;
CREATE TABLE `loveshow_interval_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `gift_name` varchar(30) NOT NULL COMMENT '礼物名称',
  `exp` int(10) NOT NULL COMMENT '消耗爱钻所得经验',
  `price` int(10) NOT NULL COMMENT '礼物价格',
  `gid` int(10) NOT NULL COMMENT 'gift id',
  `send_times` int(10) NOT NULL COMMENT '送礼次数',
  `consume_diamonds` int(10) NOT NULL COMMENT '消耗爱钻',
  `ctime` varchar(20) NOT NULL COMMENT '开始时间',
  `etime` varchar(20) NOT NULL COMMENT '结束时间',
  `grain_type` tinyint(2) NOT NULL COMMENT '粒度 0:30分钟，1:1小时，2:3小时，3:6小时，4:12小时，5:天',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12736 DEFAULT CHARSET=utf8mb4 COMMENT='小爱礼物消耗曲线';

-- ----------------------------
-- Table structure for loveshow_live_anchor
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_live_anchor`;
CREATE TABLE `loveshow_live_anchor` (
  `live_anchors` int(10) NOT NULL COMMENT '主播人数',
  `anchor_type` tinyint(2) NOT NULL COMMENT '0:家族签约，1:官方签约、2：家族认证、3：官方认证',
  `recv_anchors` int(10) NOT NULL COMMENT '收礼用户数',
  `recv_beans` int(10) NOT NULL COMMENT '收到爱豆数',
  `live_duration` int(15) NOT NULL COMMENT '开播时长',
  `stats_date` varchar(20) NOT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COMMENT='每日主播开播人数,开播类型，官方签约，家族签约，官方认证，家族认证';

-- ----------------------------
-- Table structure for loveshow_live_quality
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_live_quality`;
CREATE TABLE `loveshow_live_quality` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sampling_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `type` tinyint(2) DEFAULT NULL,
  `version` varchar(32) DEFAULT NULL,
  `anchor_id` int(10) DEFAULT NULL,
  `stream_url` varchar(50) DEFAULT NULL,
  `frame_rate` double(8,2) DEFAULT NULL,
  `bit_rate` double(8,2) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_new_live_anchor
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_new_live_anchor`;
CREATE TABLE `loveshow_new_live_anchor` (
  `live_anchors` int(10) NOT NULL COMMENT '主播人数',
  `anchor_type` tinyint(2) NOT NULL COMMENT '0:家族签约，1:官方签约、2：家族认证、3：官方认证',
  `recv_anchors` int(10) NOT NULL COMMENT '收礼用户数',
  `recv_beans` int(10) NOT NULL COMMENT '收到爱豆数',
  `live_duration` int(15) NOT NULL COMMENT '开播时长',
  `stats_date` varchar(20) NOT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COMMENT='每日新主播开播人数,开播类型，官方签约，家族签约，官方认证，家族认证\r\n新主播的筛选条件是注册未满30天（含30天）';

-- ----------------------------
-- Table structure for loveshow_new_register_user_snapshots
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_new_register_user_snapshots`;
CREATE TABLE `loveshow_new_register_user_snapshots` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ctime` varchar(20) DEFAULT NULL COMMENT '注册日期',
  `scope` int(2) NOT NULL,
  `register_users` int(10) NOT NULL COMMENT '新增用户数',
  `recharge_amounts` int(10) DEFAULT NULL COMMENT '总充值金额',
  `stats_date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5290 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_new_user
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_new_user`;
CREATE TABLE `loveshow_new_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `new_register_users` int(10) NOT NULL COMMENT '新增注册用户',
  `new_recharge_users` int(10) NOT NULL COMMENT '新增充值用户',
  `new_register_recharge_users` int(10) NOT NULL COMMENT '新注册首次充值用户',
  `old_register_recharge_users` int(10) NOT NULL COMMENT '以往注册首次充值用户',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='新注册、新充值用户';

-- ----------------------------
-- Table structure for loveshow_online_heartbeat_event
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_online_heartbeat_event`;
CREATE TABLE `loveshow_online_heartbeat_event` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sampling_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `uid` int(10) DEFAULT NULL,
  `bps` int(10) DEFAULT NULL COMMENT '码率',
  `term` tinyint(2) DEFAULT NULL COMMENT '0:安卓 1:IOS',
  `location` varchar(32) DEFAULT NULL,
  `rid` int(10) DEFAULT NULL,
  `isp` varchar(32) DEFAULT NULL,
  `streamid` varchar(255) DEFAULT NULL,
  `channel` varchar(20) DEFAULT NULL,
  `model` varchar(32) DEFAULT NULL,
  `version` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13468 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_online_play_event
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_online_play_event`;
CREATE TABLE `loveshow_online_play_event` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sampling_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `online_users` int(10) DEFAULT NULL,
  `fault_times` int(10) DEFAULT NULL COMMENT '故障次数',
  `term` tinyint(2) DEFAULT NULL COMMENT '0:安卓 1:IOS',
  `location` varchar(32) DEFAULT NULL,
  `rid` int(10) DEFAULT NULL,
  `isp` varchar(32) DEFAULT NULL,
  `type` tinyint(2) DEFAULT NULL,
  `total_online_users` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9051 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_online_stream_detail
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_online_stream_detail`;
CREATE TABLE `loveshow_online_stream_detail` (
  `isp` varchar(32) DEFAULT NULL COMMENT '码率',
  `rid` int(10) DEFAULT NULL COMMENT '0:安卓 1:IOS',
  `channel` varchar(32) DEFAULT NULL,
  `term` tinyint(2) DEFAULT NULL,
  `nettype` int(10) DEFAULT NULL,
  `stream_times` int(10) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL,
  `etime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `isp` (`isp`,`rid`,`channel`,`term`,`nettype`,`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_online_stream_dimension
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_online_stream_dimension`;
CREATE TABLE `loveshow_online_stream_dimension` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sampling_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `rid` int(11) DEFAULT NULL,
  `rid_stream_times` int(10) DEFAULT NULL,
  `isp` varchar(32) DEFAULT NULL,
  `isp_stream_times` int(10) DEFAULT NULL COMMENT '码率',
  `channel` varchar(32) DEFAULT NULL,
  `channel_stream_times` int(10) DEFAULT NULL COMMENT '0:安卓 1:IOS',
  `term` tinyint(2) DEFAULT NULL,
  `term_stream_times` int(10) DEFAULT NULL,
  `nettype` int(10) DEFAULT NULL,
  `nettype_stream_times` int(10) DEFAULT NULL,
  `stream_times` int(10) DEFAULT NULL,
  `ts_stream_times` int(10) DEFAULT NULL,
  `total_stream_times` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17612 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_online_stream_total_dimension
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_online_stream_total_dimension`;
CREATE TABLE `loveshow_online_stream_total_dimension` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rid_stream_times` int(10) DEFAULT NULL,
  `isp_stream_times` int(10) DEFAULT NULL COMMENT '码率',
  `channel_stream_times` int(10) DEFAULT NULL COMMENT '0:安卓 1:IOS',
  `term_stream_times` int(10) DEFAULT NULL,
  `nettype_stream_times` int(10) DEFAULT NULL,
  `ts_stream_times` int(10) DEFAULT NULL,
  `total_stream_times` int(10) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `etime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_online_users
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_online_users`;
CREATE TABLE `loveshow_online_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sampling_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `online_users` int(10) DEFAULT NULL,
  `type` int(10) DEFAULT NULL COMMENT '故障次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1861 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_platform_live_avg
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_platform_live_avg`;
CREATE TABLE `loveshow_platform_live_avg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) DEFAULT NULL,
  `live_anchors` int(10) NOT NULL,
  `recv_beans` int(10) NOT NULL,
  `scope` tinyint(2) NOT NULL,
  `avg_bean` double(20,2) NOT NULL,
  `avg_duration` double(20,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for loveshow_platform_live_peak
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_platform_live_peak`;
CREATE TABLE `loveshow_platform_live_peak` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `peak_users` int(10) DEFAULT NULL,
  `peak_time` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1441 DEFAULT CHARSET=utf8mb4 COMMENT='每分钟所有开播房间总人数';

-- ----------------------------
-- Table structure for loveshow_recharge_app
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_recharge_app`;
CREATE TABLE `loveshow_recharge_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `type` tinyint(2) NOT NULL COMMENT '充值类型0：小爱、1：云图、2:a8、3:微信公众号',
  `recharge_diamonds` int(10) NOT NULL COMMENT '爱钻',
  `recharge_users` int(10) NOT NULL COMMENT '充值人数',
  `recharge_times` int(10) NOT NULL COMMENT '充值次数',
  `recharge_amounts` int(10) NOT NULL COMMENT '充值金额',
  `arpu` double(10,2) NOT NULL COMMENT 'arpu = recharge_amounts/recharge_users',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COMMENT='小爱充值详情（入口：小爱、a8、云图、微信公众号）';

-- ----------------------------
-- Table structure for loveshow_recharge_grade
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_recharge_grade`;
CREATE TABLE `loveshow_recharge_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scope` int(2) NOT NULL,
  `amounts` int(10) DEFAULT NULL,
  `recharge_times` int(10) NOT NULL,
  `recharge_users` int(10) NOT NULL,
  `stats_date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COMMENT='每日各档位充值情况';

-- ----------------------------
-- Table structure for loveshow_recharge_overview
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_recharge_overview`;
CREATE TABLE `loveshow_recharge_overview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `recharge_diamonds` int(10) NOT NULL COMMENT '充值爱钻数',
  `recharge_users` int(10) NOT NULL COMMENT '充值用户数',
  `recharge_times` int(10) NOT NULL COMMENT '充值次数',
  `recharge_amounts` int(10) NOT NULL COMMENT '充值金额',
  `arpu` double(10,2) NOT NULL COMMENT 'arpu = recharge_amounts/recharge_users',
  `exchange_diamonds` int(10) DEFAULT NULL COMMENT '兑换爱钻数',
  `exchange_beans` int(10) DEFAULT NULL COMMENT '兑换爱豆数',
  `exchange_users` int(10) DEFAULT NULL COMMENT '兑换用户数',
  `consume_diamonds` int(10) DEFAULT NULL COMMENT '消费爱钻数',
  `consume_users` int(10) DEFAULT NULL COMMENT '送礼用户数',
  `recv_anchors` int(10) DEFAULT NULL COMMENT '收礼主播数',
  `large_amounts` int(10) DEFAULT '0' COMMENT '大额充值，后台管理员充值',
  `large_diamonds` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='小爱充值总览';

-- ----------------------------
-- Table structure for loveshow_recharge_time_distributed
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_recharge_time_distributed`;
CREATE TABLE `loveshow_recharge_time_distributed` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `recharge_date` varchar(32) DEFAULT NULL,
  `scope` int(11) NOT NULL,
  `recharge_times` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COMMENT='充值时间分布';

-- ----------------------------
-- Table structure for loveshow_register_accumulated_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_register_accumulated_recharge`;
CREATE TABLE `loveshow_register_accumulated_recharge` (
  `user_num` int(10) NOT NULL COMMENT '充值用户数',
  `total_amount` int(15) NOT NULL COMMENT '充值总金额',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) NOT NULL COMMENT '0：小R(1-1000)，1：中R(1001-10000)，2：大R(10001-50000)，3：超R(50000以上)',
  `stats_date` date DEFAULT NULL COMMENT '统计日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='小爱累计充值统计';

-- ----------------------------
-- Table structure for loveshow_register_interval_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_register_interval_recharge`;
CREATE TABLE `loveshow_register_interval_recharge` (
  `recharge_amount` double DEFAULT NULL COMMENT '充值金额',
  `recharge_amount_total` double DEFAULT NULL COMMENT '每天充值总金额',
  `recharge_times` bigint(20) NOT NULL COMMENT '充值次数',
  `recharge_times_total` bigint(20) NOT NULL COMMENT '每天充值总次数',
  `recharge_users` bigint(20) NOT NULL COMMENT '充值用户数',
  `recharge_users_total` bigint(20) NOT NULL COMMENT '每天充值总用户数',
  `stats_date` text COLLATE utf8mb4_unicode_ci COMMENT '充值日期',
  `scope` int(11) NOT NULL COMMENT '0：注册(0,1]，1：注册(1,3]，2：注册(3,7]，3：注册(7,14]，4：注册(14,21]，5：注册(21,28]，6：注册(28,56]，7：注册(56天以上)',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='小爱注册时间区间内充值金额统计';

-- ----------------------------
-- Table structure for loveshow_top_anchor
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_top_anchor`;
CREATE TABLE `loveshow_top_anchor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `recv_beans` int(12) DEFAULT NULL COMMENT '收到爱豆数',
  `consume_users` int(10) NOT NULL COMMENT '送礼用户数',
  `stats_date` varchar(20) DEFAULT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `nick_name` varchar(50) DEFAULT NULL,
  `anchor_type` int(2) NOT NULL COMMENT '0:总主播人数，1：认证主播人数、2：平台签约主播人数、3：家族签约主播人数、4：平台认证主播人数、5：家族认证主播人数',
  `live_durations` int(10) DEFAULT NULL COMMENT '直播时长、跨天直播按开始时间算',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COMMENT='每日Top主播收礼';

-- ----------------------------
-- Table structure for loveshow_top_consume
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_top_consume`;
CREATE TABLE `loveshow_top_consume` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL,
  `consume_diamonds` int(12) DEFAULT NULL COMMENT '消耗爱钻数',
  `stats_date` varchar(20) DEFAULT NULL,
  `nick_name` varchar(50) DEFAULT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COMMENT='每日Top送礼用户，即消费爱钻';

-- ----------------------------
-- Table structure for loveshow_top_gift
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_top_gift`;
CREATE TABLE `loveshow_top_gift` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `gid` int(10) NOT NULL,
  `gift_name` varchar(50) NOT NULL,
  `consume_users` int(10) NOT NULL COMMENT '送礼用户数',
  `recv_anchors` int(10) NOT NULL COMMENT '收礼主播数',
  `gift_price` int(10) NOT NULL COMMENT '礼物价格',
  `consume_diamonds` int(12) NOT NULL COMMENT '礼物总消耗爱钻数',
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COMMENT='每日Top礼物消耗最多';

-- ----------------------------
-- Table structure for loveshow_top_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_top_recharge`;
CREATE TABLE `loveshow_top_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  `recharge_amounts` int(10) DEFAULT NULL,
  `recharge_times` int(10) NOT NULL,
  `max_amount` int(10) DEFAULT NULL,
  `min_amount` int(10) DEFAULT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `nick_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COMMENT='每日Top充值用户数';

-- ----------------------------
-- Table structure for loveshow_user_accumulate_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_user_accumulate_recharge`;
CREATE TABLE `loveshow_user_accumulate_recharge` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `scope` tinyint(2) NOT NULL COMMENT '0:(0-1000]，1:(1000,10000]，2:(10000,50000]，3:(50000,100000]，4:(100000以上)',
  `stats_date` varchar(20) NOT NULL,
  `recharge_amounts` int(10) NOT NULL COMMENT '充值金额',
  `recharge_times` int(10) NOT NULL,
  `recharge_users` int(10) NOT NULL,
  `consume_users` int(10) NOT NULL,
  `consume_recharge_amounts` int(10) NOT NULL COMMENT '消费了爱钻的用户充值金额',
  `consume_diamonds` int(10) NOT NULL,
  `recharge_diamonds` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='根据用户累计充值金额分类统计用户当天的充值次数、充值金额、消费爱钻';

-- ----------------------------
-- Table structure for loveshow_user_gift
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_user_gift`;
CREATE TABLE `loveshow_user_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stats_date` varchar(20) NOT NULL,
  `consume_diamonds` int(10) NOT NULL COMMENT '消耗爱钻',
  `consume_users` int(10) NOT NULL COMMENT '送礼用户数',
  `recv_anchors` int(10) NOT NULL COMMENT '送礼主播数',
  `type` tinyint(2) NOT NULL COMMENT '0:直播间送礼、1:私信送礼、2:总送礼',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10625 DEFAULT CHARSET=utf8mb4 COMMENT='小爱每日用户送礼数和主播接收数';

-- ----------------------------
-- Table structure for loveshow_user_register_time_distributed
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_user_register_time_distributed`;
CREATE TABLE `loveshow_user_register_time_distributed` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `register_users` int(10) NOT NULL COMMENT '注册用户数',
  `ctime` varchar(20) DEFAULT NULL,
  `recharge_amounts` int(10) DEFAULT NULL,
  `scope` int(2) NOT NULL,
  `stats_date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29139 DEFAULT CHARSET=utf8mb4 COMMENT='注册时间分布按累计充值金额统计';

-- ----------------------------
-- Table structure for loveshow_user_remain_diamond
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_user_remain_diamond`;
CREATE TABLE `loveshow_user_remain_diamond` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `scope` int(2) NOT NULL,
  `users` int(10) NOT NULL,
  `remain_diamonds` int(10) DEFAULT NULL,
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='用户剩余爱钻';

-- ----------------------------
-- Table structure for loveshow_vest_recharge
-- ----------------------------
DROP TABLE IF EXISTS `loveshow_vest_recharge`;
CREATE TABLE `loveshow_vest_recharge` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `recharge_users` int(10) NOT NULL,
  `recharge_times` int(10) DEFAULT NULL,
  `recharge_amounts` int(10) DEFAULT NULL,
  `app` varchar(32) DEFAULT NULL,
  `stats_date` varchar(20) NOT NULL,
  `term` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COMMENT='马甲充值金额';

-- ----------------------------
-- Table structure for oneshow_anchor_data
-- ----------------------------
DROP TABLE IF EXISTS `oneshow_anchor_data`;
CREATE TABLE `oneshow_anchor_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cnick_name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` tinyint(2) DEFAULT NULL COMMENT '主播类型(0:无，1:认证，2:签约)',
  `tag` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '0：无，1：认证',
  `sign_tag` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '0：无，1：签约',
  `call_times` int(10) DEFAULT '1',
  `duration_total` int(10) DEFAULT NULL COMMENT '总通话时间',
  `pay_total` int(10) DEFAULT NULL COMMENT '通话积分',
  `recv_times` int(10) DEFAULT NULL COMMENT '收礼次数',
  `recv_exp` int(10) DEFAULT NULL COMMENT '收礼积分',
  `request_times` int(10) DEFAULT NULL COMMENT '请求次数',
  `stats_date` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4592 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='小优主播数据统计';

-- ----------------------------
-- Table structure for oneshow_duration_distributed
-- ----------------------------
DROP TABLE IF EXISTS `oneshow_duration_distributed`;
CREATE TABLE `oneshow_duration_distributed` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `call_times_total` int(10) NOT NULL COMMENT '通话总次数',
  `call_duration_total` int(10) NOT NULL COMMENT '通话总时长',
  `send_users_total` int(10) NOT NULL COMMENT '总发起人',
  `recv_users_total` int(10) NOT NULL COMMENT '总接收人',
  `stats_date` varchar(20) NOT NULL,
  `request_times_total` int(10) NOT NULL DEFAULT '0' COMMENT '请求次数',
  `request_users_total` int(10) NOT NULL COMMENT '请求用户数',
  `request_anchors_total` int(10) NOT NULL COMMENT '被请求主播数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='每日通话基础数据';

-- ----------------------------
-- Table structure for oneshow_per_capita_distributed
-- ----------------------------
DROP TABLE IF EXISTS `oneshow_per_capita_distributed`;
CREATE TABLE `oneshow_per_capita_distributed` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `scope` int(2) NOT NULL,
  `send_users` int(10) NOT NULL,
  `call_times` int(10) DEFAULT NULL,
  `stats_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='每日人均通话时长分布';

-- ----------------------------
-- Table structure for oneshow_per_times_distributed
-- ----------------------------
DROP TABLE IF EXISTS `oneshow_per_times_distributed`;
CREATE TABLE `oneshow_per_times_distributed` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `scope` tinyint(2) NOT NULL,
  `call_times` int(10) NOT NULL,
  `stats_date` varchar(20) NOT NULL,
  `recv_users` int(10) NOT NULL,
  `send_users` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='每日次均通话时长分布';

-- ----------------------------
-- Table structure for op_log
-- ----------------------------
DROP TABLE IF EXISTS `op_log`;
CREATE TABLE `op_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `ip` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `op_type` int(3) DEFAULT NULL,
  `op_result` int(1) DEFAULT NULL,
  `op_key` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `op_data` text COLLATE utf8_unicode_ci,
  `ip_desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gmt_create` (`gmt_create`)
) ENGINE=InnoDB AUTO_INCREMENT=666 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permission` varchar(255) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for probe_counter
-- ----------------------------
DROP TABLE IF EXISTS `probe_counter`;
CREATE TABLE `probe_counter` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `probe_time` datetime DEFAULT NULL,
  `tv_id` int(11) DEFAULT NULL,
  `source` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_index` int(11) DEFAULT NULL,
  `source_url` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `isp` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `count_type` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `count_value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `probe_time_tv_id_source` (`probe_time`,`tv_id`,`source`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for probe_counter_by_url
-- ----------------------------
DROP TABLE IF EXISTS `probe_counter_by_url`;
CREATE TABLE `probe_counter_by_url` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `probe_time` datetime DEFAULT NULL,
  `tv_id` int(11) DEFAULT NULL,
  `source` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_url` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `isp` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `count_type` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `count_value` int(11) DEFAULT NULL,
  `source_label` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `probe_time_tv_id_source` (`probe_time`,`tv_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for programs
-- ----------------------------
DROP TABLE IF EXISTS `programs`;
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tv_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `epg_title` varchar(50) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `previewimg` varchar(200) NOT NULL,
  `summary` varchar(500) NOT NULL,
  `groupname` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tv_id` (`tv_id`,`epg_title`,`start_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for program_manange
-- ----------------------------
DROP TABLE IF EXISTS `program_manange`;
CREATE TABLE `program_manange` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patterns` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for program_pattern
-- ----------------------------
DROP TABLE IF EXISTS `program_pattern`;
CREATE TABLE `program_pattern` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patterns` text COLLATE utf8_unicode_ci,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `tags` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for program_recommend_rule
-- ----------------------------
DROP TABLE IF EXISTS `program_recommend_rule`;
CREATE TABLE `program_recommend_rule` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `tvid` int(11) NOT NULL,
  `tv_name` varchar(32) DEFAULT NULL,
  `title_pattern` varchar(128) DEFAULT NULL,
  `recommend` tinyint(1) NOT NULL,
  `front_page_recommend` tinyint(1) NOT NULL,
  `image` varchar(256) DEFAULT NULL,
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  `info` varchar(1024) DEFAULT NULL,
  `start_time` varchar(64) DEFAULT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `title_not_pattern` varchar(128) DEFAULT NULL,
  `topic_id` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for program_rel
-- ----------------------------
DROP TABLE IF EXISTS `program_rel`;
CREATE TABLE `program_rel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pm_id` bigint(20) DEFAULT NULL,
  `program_id` bigint(20) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for program_tag
-- ----------------------------
DROP TABLE IF EXISTS `program_tag`;
CREATE TABLE `program_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `program_id` bigint(20) DEFAULT NULL,
  `tag_id` bigint(20) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id` (`program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for program_tag_history
-- ----------------------------
DROP TABLE IF EXISTS `program_tag_history`;
CREATE TABLE `program_tag_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `program_id` bigint(20) DEFAULT NULL,
  `tag_id` bigint(20) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `program_id` (`program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for push_messages
-- ----------------------------
DROP TABLE IF EXISTS `push_messages`;
CREATE TABLE `push_messages` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `description` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `track_id` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for realtime_events
-- ----------------------------
DROP TABLE IF EXISTS `realtime_events`;
CREATE TABLE `realtime_events` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `event_type` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for roles_permissions
-- ----------------------------
DROP TABLE IF EXISTS `roles_permissions`;
CREATE TABLE `roles_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permission` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_permission` (`role_name`,`permission`)
) ENGINE=InnoDB AUTO_INCREMENT=951 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for source_error_record
-- ----------------------------
DROP TABLE IF EXISTS `source_error_record`;
CREATE TABLE `source_error_record` (
  `tvid` int(11) NOT NULL,
  `record_date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `record` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`tvid`,`record_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for stats
-- ----------------------------
DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stats_group` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `stats_key` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `val1` decimal(10,2) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `stats_date` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_key_date` (`stats_group`,`stats_key`,`stats_date`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tags
-- ----------------------------
DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `desc` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `ref1` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for topic_banner_items
-- ----------------------------
DROP TABLE IF EXISTS `topic_banner_items`;
CREATE TABLE `topic_banner_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint(20) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `index` int(11) DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `conf_group` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for ts_probe
-- ----------------------------
DROP TABLE IF EXISTS `ts_probe`;
CREATE TABLE `ts_probe` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `key1` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `key2` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `val1` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tvmao_epg
-- ----------------------------
DROP TABLE IF EXISTS `tvmao_epg`;
CREATE TABLE `tvmao_epg` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `channel_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `epg_code` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_time` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_time` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel_date` (`channel_id`,`date`),
  KEY `gmt_modify` (`gmt_modify`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tvs
-- ----------------------------
DROP TABLE IF EXISTS `tvs`;
CREATE TABLE `tvs` (
  `id` int(11) NOT NULL,
  `tv_name` varchar(30) NOT NULL,
  `hot` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `img` varchar(100) NOT NULL DEFAULT '',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tv_stats
-- ----------------------------
DROP TABLE IF EXISTS `tv_stats`;
CREATE TABLE `tv_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_stats` datetime DEFAULT NULL,
  `tv_id` int(11) DEFAULT NULL,
  `source` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `value1` int(11) DEFAULT NULL,
  `tag1` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `stats_date` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stats_date` (`stats_date`,`tv_id`),
  KEY `gmt_stats_tv_id` (`gmt_stats`,`tv_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=65992755 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tv_tag
-- ----------------------------
DROP TABLE IF EXISTS `tv_tag`;
CREATE TABLE `tv_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tv_id` bigint(20) DEFAULT NULL,
  `tag_id` bigint(20) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tv_id_tag_d` (`tv_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for tv_watch
-- ----------------------------
DROP TABLE IF EXISTS `tv_watch`;
CREATE TABLE `tv_watch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wid` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_ts` bigint(20) DEFAULT NULL,
  `elapse` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_start_ts` (`uid`,`start_ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for tv_watch_geo
-- ----------------------------
DROP TABLE IF EXISTS `tv_watch_geo`;
CREATE TABLE `tv_watch_geo` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `watch_date` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tvid` int(11) DEFAULT NULL,
  `province` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for txn_data
-- ----------------------------
DROP TABLE IF EXISTS `txn_data`;
CREATE TABLE `txn_data` (
  `topic` varchar(32) DEFAULT NULL,
  `metric` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for umeng_app
-- ----------------------------
DROP TABLE IF EXISTS `umeng_app`;
CREATE TABLE `umeng_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `app_key` varchar(64) DEFAULT NULL,
  `app_name` varchar(128) DEFAULT NULL,
  `platform` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `platform_app` (`app_key`,`platform`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for umeng_base_data
-- ----------------------------
DROP TABLE IF EXISTS `umeng_base_data`;
CREATE TABLE `umeng_base_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `stats_date` varchar(10) DEFAULT NULL,
  `app_key` varchar(64) DEFAULT NULL,
  `installations` int(11) DEFAULT NULL,
  `new_users` int(11) DEFAULT NULL,
  `active_users` int(11) DEFAULT NULL,
  `launches` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stats_date_app` (`stats_date`,`app_key`)
) ENGINE=InnoDB AUTO_INCREMENT=862 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for user_channels
-- ----------------------------
DROP TABLE IF EXISTS `user_channels`;
CREATE TABLE `user_channels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `channel_code` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `conf_group` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `channel_name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `gmt_modify` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=417 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for user_recharge_accumulated
-- ----------------------------
DROP TABLE IF EXISTS `user_recharge_accumulated`;
CREATE TABLE `user_recharge_accumulated` (
  `user_num` int(10) NOT NULL COMMENT '充值用户数',
  `total_amount` int(15) NOT NULL COMMENT '充值总金额',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) NOT NULL COMMENT '0：小R(1-1000)，1：中R(1001-10000)，2：大R(10001-50000)，3：超R(50000以上)',
  `stats_date` date DEFAULT NULL COMMENT '统计日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='小爱累计充值统计';

-- ----------------------------
-- Table structure for user_register_recharge
-- ----------------------------
DROP TABLE IF EXISTS `user_register_recharge`;
CREATE TABLE `user_register_recharge` (
  `price` int(11) NOT NULL COMMENT '充值金额',
  `stats_date` date DEFAULT NULL COMMENT '统计日期',
  `scope` int(11) NOT NULL COMMENT '注册N天内，0表示56天以上',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COMMENT='小爱注册时间段内累计充值统计';

-- ----------------------------
-- Table structure for user_roles
-- ----------------------------
DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_role` (`username`,`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for user_tag
-- ----------------------------
DROP TABLE IF EXISTS `user_tag`;
CREATE TABLE `user_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_id` bigint(20) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_tag_id` (`uid`,`tag_id`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for user_vests
-- ----------------------------
DROP TABLE IF EXISTS `user_vests`;
CREATE TABLE `user_vests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vest_code` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `conf_group` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vest_name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `gmt_modify` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for vest
-- ----------------------------
DROP TABLE IF EXISTS `vest`;
CREATE TABLE `vest` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `vest_code` varchar(32) DEFAULT NULL,
  `vest_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `conf_group` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vest_code` (`vest_code`)
) ENGINE=InnoDB AUTO_INCREMENT=854 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for videos
-- ----------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group1` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `props` text COLLATE utf8_unicode_ci,
  `status` int(11) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  `delete_flag` int(1) DEFAULT NULL,
  `unique_url` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_expire` datetime DEFAULT NULL,
  `error_count` int(11) DEFAULT NULL,
  `last_error` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt_fetch` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gmt_modify` (`gmt_modify`),
  KEY `unqiue_url` (`unique_url`(100)) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
