package com.yuntu.stats.stream

import org.apache.spark.SparkConf
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Minutes, Seconds, StreamingContext}

/**
  * Created by Administrator on 2017/6/13 0013.
  */
object FirstStream {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("FirstStream")
    val context = new StreamingContext(conf, Seconds(1))
    val dStream = KafkaUtils.createStream(context,"localhost:2181","group1",Map("test"-> 1))
    println(dStream.count())
    dStream.print()
    context.start()
    context.awaitTermination()
  }
}
