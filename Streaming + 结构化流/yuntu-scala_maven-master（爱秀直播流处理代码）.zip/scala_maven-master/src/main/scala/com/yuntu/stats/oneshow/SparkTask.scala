package com.yuntu.stats.oneshow

import com.yuntu.stats.config.Config
import com.yuntu.stats.config.Config.parser
import com.yuntu.stats.udf.UdfFunction
import com.yuntu.stats.utils.JdbcConfig
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.slf4j.LoggerFactory

/**
  * Created by Administrator on 2017/6/5 0005.
  */
object SparkTask {
  val log = LoggerFactory.getLogger(this.getClass)
  val pattern = "\\[(\\d{4}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}:\\d{2}?).*\\[cgi/ask_connect_mic\\.cpp:\\d+\\]OpInfo:SHChatReq\\(head=SessionHeader.*?tuid=(\\d+?),.*uid=(\\d+?),.*".r
  var today=""

  def main(args: Array[String]): Unit = {
//    parser.parse(Seq("--debug","-p","C:\\Users\\Administrator\\Desktop\\oneshow\\","-c","2017-06-28","-t","anchor_data"), Config()) match {
          parser.parse(args.toSeq, Config()) match {
      case Some(config) => {
        val sparkSession = if(config.debug){
          System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4");
          SparkSession.builder().appName("").master("local[*]").getOrCreate()
        } else {
          SparkSession.builder().appName("").getOrCreate()
        }
        today=config.currentDate
        defaultTable(sparkSession,config.hdfsPath)
        config.taskNames.foreach(executeTask(_,sparkSession))
        log.error(config.toString)
      }
      case None => log.error("args error")
    }
  }

  def executeTask(taskName:String,sparkSession: SparkSession)={
    UdfFunction(sparkSession);
    taskName match {
      case "anchor_data" => sparkSession.sql(OneShowSql.anchor_detail_data).coalesce(4).toDF().write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "oneshow_anchor_data", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "per_capita_distributed" => sparkSession.sql(OneShowSql.per_capita_distributed).coalesce(4).toDF().write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "oneshow_per_capita_distributed", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "per_times_distributed" => sparkSession.sql(OneShowSql.per_times_distributed).coalesce(4).toDF().write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "oneshow_per_times_distributed", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "duration_distributed" => sparkSession.sql(OneShowSql.duration_distributed).join(sparkSession.sql(OneShowSql.request_day),"stats_date").coalesce(4).toDF().write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "oneshow_duration_distributed", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "abc" => sparkSession.sql(OneShowSql.abc).show(1000)
      case _ if taskName!=null => log.error(s"no such task $taskName !")
      case _ => log.error(s"no such task $taskName !")
    }
  }

  def defaultTable(sparkSession: SparkSession,path:String)={
    (
      ("user","user/*.parquet"),
      ("gift_history","gift_history/*.parquet"),
      ("live_room_history","live_room_history/*.parquet"),
      ("ask_room_history","ask_room_history/*.parquet")
//      ("request_record","oneshow*20170608/*")
    ).productIterator.foreach(v => {
      v match{
        case ("request_record",fileName:String) => registerCgiLog(sparkSession,path,fileName)
        case (tableName:String,fileName:String) => sparkSession.sql("select * from parquet.`"+path+ fileName +"`").createOrReplaceTempView(tableName)
        case _ => log.error(s"no such file ${v}")
      }
    })
  }

  def registerCgiLog(sparkSession: SparkSession,path:String,fileName:String)={
    val textfile = sparkSession.read.textFile(path+fileName)
    val rdd =textfile.filter((line: String) => {
      !pattern.findAllIn(line).isEmpty
    }).distinct().rdd.map((line: String) => {
      val pattern(ctime, tuid, uid) = line
      Row(ctime, tuid, uid)
    })

    sparkSession.createDataFrame(rdd,StructType(
      StructField("ctime", StringType, true) ::
      StructField("tuid", StringType, true) ::
      StructField("uid", StringType, true) :: Nil)).createOrReplaceTempView("request_record")
  }
}
