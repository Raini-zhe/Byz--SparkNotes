package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object ActiveSQL {
  /**
    * 马甲日活
    */
  val active_vest_user=
    s"""
       |SELECT COUNT(1) active_users,
       |       if(trim(t1.app)='','weizhi',t1.app) vest,
       |       t1.term,
       |       sum(if(t2.tuid IS NULL, 0, 1)) active_recharge_users,
       |       '${SparkEnv.today}' stats_date
       |  FROM(
       |SELECT app, channel, term,uid
       |  FROM user where date(activetime)= '${SparkEnv.today}' and istest=0 and deleted=0
       |) t1
       |  LEFT JOIN
       |(
       |select tuid from orders where status= 1
       |   AND fee> 0
       |   AND date(create_time)<= '${SparkEnv.today}' group by tuid
       |) t2 on t1.uid=t2.tuid
       | GROUP BY t1.app, t1.term
     """.stripMargin

  /**
    * 渠道日活
    */
  val active_channel_user=
    s"""
       |SELECT COUNT(1) active_users,
       |       if(trim(t1.channel)='','apple',t1.channel) channel,
       |       t1.term,
       |       sum(if(t2.tuid IS NULL, 0, 1)) active_recharge_users,
       |       '${SparkEnv.today}' stats_date
       |  FROM(
       |SELECT app, channel, term,uid
       |  FROM user where date(activetime)= '${SparkEnv.today}' and istest=0 and deleted=0
       |) t1
       |  LEFT JOIN
       |(
       |select tuid from orders where status= 1
       |   AND fee> 0
       |   AND date(create_time)<= '${SparkEnv.today}' group by tuid
       |) t2 on t1.uid=t2.tuid
       | GROUP BY t1.channel, t1.term
     """.stripMargin

  /**
    * 根据用户累计充值金额分类统计活跃用户数
    */
  val active_recharge_user=
    s"""
       |SELECT '${SparkEnv.today}' stats_date,SUM(t4.recharge_times) recharge_times,COUNT(DISTINCT(t4.tuid)) recharge_users,SUM(t4.recharge_amounts) recharge_amounts, COUNT(DISTINCT(t4.uid)) active_users,t4.scope FROM
       |(
       |SELECT
       |	t1.uid ,
       |	CASE WHEN t2.recharge_amounts>0 and t2.recharge_amounts<=1000 THEN 0
       |	WHEN t2.recharge_amounts>1000 and t2.recharge_amounts<=10000 THEN 1
       |	WHEN t2.recharge_amounts>10000 and t2.recharge_amounts<=50000 THEN 2
       |	WHEN t2.recharge_amounts>50000 and t2.recharge_amounts<=100000 THEN 3
       |	WHEN t2.recharge_amounts>100000 THEN 4 ELSE -1 END scope,
       |  t3.tuid,
       |	t3.recharge_times,
       |	t3.recharge_amounts,
       |	t3.recharge_diamonds
       |FROM user t1 LEFT JOIN
       |(
       |	SELECT SUM(price)/100 recharge_amounts,tuid ,COUNT(1) recharge_times FROM orders WHERE date(create_time) <='${SparkEnv.today}' and status=1 and fee>0 GROUP BY tuid
       |) t2 on t1.uid=t2.tuid LEFT JOIN
       |(
       |	SELECT tuid,SUM(price)/100 recharge_amounts,COUNT(1) recharge_times,SUM(total_amount) recharge_diamonds FROM orders WHERE date(create_time)='${SparkEnv.today}' and status =1 and fee>0 GROUP BY tuid
       |) t3 on t1.uid=t3.tuid WHERE date(t1.activetime) ='${SparkEnv.today}'
       |) t4 GROUP BY t4.scope
     """.stripMargin

  /**
    * 根据不同APP注册统计活跃度
    */
  val active_app_user=
    s"""
       |SELECT COUNT(1) active_users,
       |       t1.login_from,
       |       t1.term,
       |       sum(if(t2.tuid IS NULL, 0, 1)) active_recharge_users,
       |       '${SparkEnv.today}' stats_date
       |  FROM (
       |SELECT app,channel,term,uid,
       |      CASE WHEN login_from=0 or login_from=1 or login_from=2 or login_from=3 THEN 0
       |      ELSE login_from  end login_from
       |  FROM user where date(activetime)= '${SparkEnv.today}' and istest=0 and deleted=0
       |) t1
       |  LEFT JOIN
       |(
       |select tuid from orders where status= 1
       |   AND fee> 0
       |   AND date(create_time)<= '${SparkEnv.today}' group by tuid
       |) t2 on t1.uid=t2.tuid
       | GROUP BY t1.login_from, t1.term
     """.stripMargin
}
