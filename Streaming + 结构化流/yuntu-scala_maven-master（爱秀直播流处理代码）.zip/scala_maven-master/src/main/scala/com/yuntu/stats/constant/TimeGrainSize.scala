package com.yuntu.stats.constant

/**
  * Created by liss on 17-5-23.
  */
object CommonConstant {
  val GRAIN_0 = Tuple3(30*60*1000,"30分钟",0)
  val GRAIN_1 = Tuple3(60*60*1000,"1小时",1)
  val GRAIN_2 = Tuple3(60*60*3*1000,"3小时",2)
  val GRAIN_3 = Tuple3(60*60*6*1000,"6小时",3)
  val GRAIN_4 = Tuple3(60*60*12*1000,"12小时",4)
  val GRAIN_5 = Tuple3(60*60*24*1000,"天",5)

  val timeGrainSize = GRAIN_0::GRAIN_1::GRAIN_2::GRAIN_3::GRAIN_4::GRAIN_5::Nil
}
