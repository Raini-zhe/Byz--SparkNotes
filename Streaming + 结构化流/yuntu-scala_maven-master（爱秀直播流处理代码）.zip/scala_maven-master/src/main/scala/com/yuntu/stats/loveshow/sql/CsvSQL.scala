package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object CsvSQL {
  /**
    * 马甲日活
    */
  val csvSql=
    s"""
       |SELECT
       |	u.uid ,
       |	u.cnick_name,
       |	i.recv_exp,
       |	sumi.month_total,
       |	u.cidentification,
       |	sumd.sumvalid,
       |	(sumd.summinutes/60),
       |	u.ctag,
       |	date(n.ntime),
       |	date(m.mtime)
       |FROM user u
       |join user_info i on i.uid =u.uid
       |JOIN ( SELECT d.uid ,SUM(d.valid) as sumvalid , SUM(d.minutes) as summinutes FROM live_room_day d WHERE date(d.ctime) >='${SparkEnv.today}' and date(d.ctime) <=current_date() GROUP BY d.uid ) as sumd on sumd.uid =u.uid
       |JOIN ( SELECT ih.uid ,SUM(ih.amount) as month_total FROM income_history ih WHERE date(ih.ctime) >='${SparkEnv.today}' and date(ih.ctime) <=current_date() GROUP BY ih.uid ) as sumi on sumi.uid =u.uid
       |JOIN (select MIN(h.ctime) AS  ntime, u1.uid as uid   from user u1 JOIN `live_room_history` h ON h.uid = u1.uid WHERE u1.tag <>''  group by u1.uid ) n ON n.uid = u.uid
       |JOIN (select max(h.ctime) AS  mtime, u1.uid as uid   from user u1 JOIN `live_room_history` h ON h.uid = u1.uid WHERE u1.tag <>''  group by u1.uid ) m ON m.uid = u.uid
       |WHERE u.tag <>''
       |ORDER BY sumi.month_total DESC
       |
     """.stripMargin

  val wdc=
    s"""
       |select t3.*,sum(t3.exp) over(partition by t3.ctime) total_exp from
       |(
       |select
       |  rank() over(partition by t2.ctime order by exp desc) rank,
       |  t2.tuid,
       |  t2.ctime,
       |  t2.exp
       | from
       |(
       | SELECT
       |  max(date_format(t1.`ctime`,'yyyy-MM-dd HH')) ctime,
       |  SUM(t1.`recv_exp`) exp,
       |  t1.tuid
       | FROM
       |(
       |SELECT * FROM `gift_history` WHERE date(`ctime`) >='2017-05-17' and date(`ctime`) <='2017-07-17' and date_format(`ctime`,'HH')>=19 and date_format(`ctime`,'HH')<=23
       |union
       |SELECT * FROM `gift_history` WHERE date(`ctime`) >='2017-05-17' and date(`ctime`) <='2017-07-17' and date_format(`ctime`,'HH')>=00 and date_format(`ctime`,'HH')<01
       |) t1
       |GROUP BY date_format(t1.`ctime`,'yyyy-MM-dd HH'),t1.tuid
       |) t2
       |) t3 where t3.rank<=3 order by t3.ctime,t3.rank
     """.stripMargin

}
