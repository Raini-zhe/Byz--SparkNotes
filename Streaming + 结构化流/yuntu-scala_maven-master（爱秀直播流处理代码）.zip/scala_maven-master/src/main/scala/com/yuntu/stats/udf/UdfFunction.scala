package com.yuntu.stats.udf

import java.text.SimpleDateFormat

import org.apache.spark.sql.SparkSession

/**
  * Created by liss on 17-5-22.
  */

class UdfFunction(sparkSession: SparkSession){
  sparkSession.sqlContext.udf.register("date",(l:Long)=>new SimpleDateFormat("yyyy-MM-dd").format(l))

  sparkSession.sqlContext.udf.register("date_format",(date:AnyVal,format:String)=>
    format match {
      case "yyyy-MM-dd" => new SimpleDateFormat(format).format(date)
      case "yyyy-MM-dd HH" => new SimpleDateFormat(format).format(date)
      case "yyyy-MM-dd HH:mm" => new SimpleDateFormat(format).format(date)
      case "yyyy-MM-dd HH:mm:ss" => new SimpleDateFormat(format).format(date)
      case _ => new SimpleDateFormat(format).format(date)
    }
  )
}

object UdfFunction {
  def apply(sparkSession: SparkSession): UdfFunction = new UdfFunction(sparkSession)
}
