package com.yuntu.stats.loveshow

/**
  * Created by liss on 17-5-21.
  */
object LoveShowSql{

  /**
    * 每日Top充值
    * 用户ID、充值金额、充值次数、 最大单笔充值、最小单笔充值、注册时间、昵称
    */
  val top_recharge_user=
    s"""
       |SELECT t1.*,
       |       date(t.ctime) ctime,
       |       t.nick_name
       |  FROM user t JOIN(
       |SELECT max(DATE(create_time)) stats_date, tuid uid, SUM(price) /100 recharge_amounts, COUNT(tuid) recharge_times, MAX(price) /100 max_amount, MIN(price) /100 min_amount
       |  FROM orders
       | WHERE DATE(create_time)= '${SparkEnv.today}'
       |   AND status= 1
       | GROUP BY DATE(create_time), tuid
       | ORDER BY stats_date, recharge_amounts DESC
       | LIMIT 100) t1 ON t.uid= t1.uid
     """.stripMargin

  /**
    * 每日Top礼物消耗
    * 礼物ID、礼物名称、送礼用户数、收礼主播数、礼物价格、礼物总爱豆数
    */
  val top_gift_consume=
    s"""
       |SELECT t1.gid,
       |       max(t.name) gift_name,
       |       COUNT(DISTINCT(t1.uid)) consume_users,
       |       COUNT(DISTINCT(t1.tuid)) recv_anchors,
       |       MAX(t.price) gift_price,
       |       SUM(t1.recv_exp) consume_diamonds,
       |       max(DATE(t1.ctime)) stats_date
       |  FROM gift_item t JOIN gift_history t1 ON t.gid= t1.gid
       |   AND DATE(t1.ctime)= '${SparkEnv.today}'
       | GROUP BY DATE(t1.ctime), t1.gid
       | ORDER BY stats_date, consume_diamonds
       | LIMIT 100
     """.stripMargin

  /**
    * 每日Top消耗爱豆用户
    * 用户ID、消费爱钻、用户昵称、注册时间
    */
  val top_consume_beans_user=
    s"""
       |SELECT t1.*,
       |       t.nick_name,
       |       date(t.ctime) ctime
       |  FROM user t JOIN(
       |SELECT uid, SUM(recv_exp) consume_diamonds, max(DATE(ctime)) stats_date
       |  FROM gift_history
       | WHERE DATE(ctime)= '${SparkEnv.today}'
       | GROUP BY DATE(ctime), uid
       | ORDER BY stats_date, consume_diamonds DESC
       | LIMIT 100) t1 ON t.uid= t1.uid
     """.stripMargin

  /**
    * 每日礼物消耗数量快照，按用户累计充值统计
    */
  val gift_consume_snapshots=
    s"""
       |SELECT '${SparkEnv.today}' stats_date,
       |       t.name gift_name,
       |       t.tag gift_tag,
       |       t.price gift_price,
       |       t4.*
       |  FROM gift_item t JOIN(
       |SELECT t3.scope,sum(t3.cnt) cnt, t3.ctime, t3.gid, SUM(t3.recv_exp) consume_diamonds, COUNT(DISTINCT(t3.uid)) total_users
       |  FROM(
       |SELECT t1.uid, t1.cnt, t1.gid, t1.ctime, t1.recv_exp, CASE WHEN t2.recharge_amounts> 0
       |   and t2.recharge_amounts<= 1000 THEN 0 WHEN t2.recharge_amounts> 1000
       |   and t2.recharge_amounts<= 10000 THEN 1 WHEN t2.recharge_amounts> 10000
       |   and t2.recharge_amounts<= 50000 THEN 2 WHEN t2.recharge_amounts> 50000
       |   and t2.recharge_amounts<= 100000 THEN 3 WHEN t2.recharge_amounts> 100000 THEN 4 ELSE -1 END scope
       |  FROM(
       |SELECT date(ctime) ctime, gid, uid, recv_exp,cnt
       |  FROM gift_history
       | WHERE date(ctime)<= '${SparkEnv.today}') t1 JOIN(
       |SELECT tuid, sum(price) /100 recharge_amounts
       |  FROM orders
       | WHERE status= 1
       |   and fee> 0
       |   and date(create_time)<= '${SparkEnv.today}'
       | GROUP BY tuid) t2 on t1.uid= t2.tuid) t3
       | GROUP BY t3.scope, t3.ctime, t3.gid) t4 on t.gid= t4.gid
     """.stripMargin



  /**
    * 根据用户累计充值金额分类统计用户当天的充值次数、充值金额、消费爱钻
    */
  val user_accumulate_recharge =
    s"""
       |SELECT t.scope,'${SparkEnv.today}' stats_date,SUM(t.recharge_amounts) recharge_amounts,
       |  SUM(t.recharge_times) recharge_times,
       |  COUNT(DISTINCT(t.tuid)) recharge_users,
       |  sum(if(t.uid is null , 0 , 1)) consume_users,
       |  sum(if(t.uid is null , 0 , t.recharge_amounts)) consume_recharge_amounts,
       |  SUM(ifnull(t.consume_diamonds,0)) consume_diamonds,
       |  sum(t.recharge_diamonds) recharge_diamonds
       |  FROM
       |(
       |SELECT CASE
       |	WHEN t1.recharge_amounts>0 and t1.recharge_amounts<=1000 THEN 0
       |	WHEN t1.recharge_amounts>1000 and t1.recharge_amounts<=10000 THEN 1
       |	WHEN t1.recharge_amounts>10000 and t1.recharge_amounts<=50000 THEN 2
       |	WHEN t1.recharge_amounts>50000 and t1.recharge_amounts<=100000 THEN 3
       |	WHEN t1.recharge_amounts>100000 THEN 4 ELSE -1 END scope,
       |	t1.tuid,t2.recharge_amounts,t2.recharge_times,t2.recharge_diamonds,t3.consume_diamonds,t3.uid
       |FROM
       |(
       |	SELECT SUM(price)/100 recharge_amounts,tuid ,COUNT(1) recharge_times FROM orders WHERE date(create_time) <='${SparkEnv.today}' and status=1 and fee>0 GROUP BY tuid
       |) t1 join
       |(
       |	SELECT tuid,SUM(price)/100 recharge_amounts,COUNT(1) recharge_times,SUM(total_amount) recharge_diamonds FROM orders WHERE date(create_time)='${SparkEnv.today}' and status =1 and fee>0 GROUP BY tuid
       |) t2 on t1.tuid=t2.tuid
       |left join
       |(
       |	SELECT uid,SUM(recv_exp) consume_diamonds FROM gift_history WHERE date(ctime)='${SparkEnv.today}' GROUP BY uid
       |) t3 on t3.uid=t2.tuid
       |) t GROUP BY t.scope
     """.stripMargin

  var abc =
    s"""
       |SELECT
       |    SUM(t2.price)/100 price,
       |	t1.uid,MAX(t1.balance) balance
       |FROM user t1 LEFT JOIN orders t2 on t1.uid =t2.tuid and t2.status =1 and t2.fee >0 and date(t2.create_time) < '2017-06-02' GROUP BY t1.uid
       |ORDER BY price asc
     """.stripMargin

  /**
    * 每日新增用户数
    * 新增用户数、注册日期
    */
  val new_register_users =
    s"""
       |SELECT COUNT(1) new_register_users,max(date(ctime)) stats_date FROM user WHERE  date(ctime)='${SparkEnv.today}' group by date(ctime)
     """.stripMargin

  /**
    * 每日新增充值用户
    * 新充值用户、新用户注册并首次充值、老用户首次充值
    */
  val new_recharge_users =
    s"""
       |SELECT COUNT(1) new_recharge_users,
       |       COUNT((CASE WHEN t2.day= 0 THEN 1 END)) new_register_recharge_users,
       |       COUNT((CASE WHEN t2.day!= 0 THEN 1 END)) old_register_recharge_users,
       |       max(date(t2.min_create_time)) stats_date
       |  FROM(
       |SELECT t.uid, t.ctime, t1.min_create_time, datediff(date(t1.min_create_time), date(t.ctime)) day
       |  FROM user t JOIN(
       |SELECT MIN(create_time) min_create_time, tuid
       |  FROM orders
       | WHERE status= 1
       |   and DATE(create_time)<= '${SparkEnv.today}'
       | GROUP BY tuid) t1 on t.uid= t1.tuid
       |   and date(t1.min_create_time)= '${SparkEnv.today}') t2
       | GROUP BY date(t2.min_create_time)
     """.stripMargin

  /**
    * 每日新增用户数快照，按累计充值金额统计
    */
  val new_register_user_snapshots =
    s"""
       |SELECT t3.ctime,
       |       t3.scope,
       |       COUNT(t3.uid) register_users,
       |       SUM(t3.recharge_amounts) recharge_amounts,
       |       '${SparkEnv.today}' stats_date
       |  FROM(
       |SELECT t1.ctime, t1.uid, t2.recharge_amounts, CASE WHEN t2.recharge_amounts> 0
       |   and t2.recharge_amounts<= 1000 THEN 0 WHEN t2.recharge_amounts> 1000
       |   and t2.recharge_amounts<= 10000 THEN 1 WHEN t2.recharge_amounts> 10000
       |   and t2.recharge_amounts<= 50000 THEN 2 WHEN t2.recharge_amounts> 50000
       |   and t2.recharge_amounts<= 100000 THEN 3 WHEN t2.recharge_amounts> 100000 THEN 4 ELSE -1 END scope
       |  FROM(
       |SELECT uid, date(ctime) ctime
       |  FROM user) t1 JOIN(
       |SELECT tuid, sum(price) /100 recharge_amounts
       |  FROM orders
       | WHERE status= 1
       |   and fee> 0
       |   and date(create_time)<= '${SparkEnv.today}'
       | GROUP BY tuid) t2 ON t1.uid= t2.tuid) t3
       | GROUP BY t3.ctime, t3.scope
     """.stripMargin





  /**
    * 用户剩余爱钻
    */
  val user_remain_diamond=
    s"""
       |SELECT
       |	t3.scope,COUNT(DISTINCT(t3.uid)) users,SUM(t3.balance) remain_diamonds,'${SparkEnv.today}' stats_date
       |FROM
       |(
       |SELECT
       |	t1.uid,t1.balance,
       |	CASE
       |	WHEN t2.recharge_amounts>0 and t2.recharge_amounts<=1000 THEN 0
       |	WHEN t2.recharge_amounts>1000 and t2.recharge_amounts<=10000 THEN 1
       |	WHEN t2.recharge_amounts>10000 and t2.recharge_amounts<=50000 THEN 2
       |	WHEN t2.recharge_amounts>50000 and t2.recharge_amounts<=100000 THEN 3
       |	WHEN t2.recharge_amounts>100000 THEN 4 ELSE -1 END scope
       |FROM
       |(
       |SELECT * FROM user WHERE istest=0 and deleted=0
       |) t1 LEFT JOIN
       |(
       |SELECT tuid,SUM(price)/100 recharge_amounts FROM orders WHERE status=1 and fee>0 and date(create_time) <= '${SparkEnv.today}' GROUP BY tuid
       |) t2 on t1.uid=t2.tuid
       |) t3 GROUP BY t3.scope
     """.stripMargin

  /**
    * 首次充值时间分布
    */
  val first_recharge_time=
    s"""
       |SELECT
       |	t1.first_recharge_time,
       |  COUNT(DISTINCT(t.uid)) recharge_users,
       |  '${SparkEnv.today}' stats_date
       |FROM user t
       |JOIN
       |(
       |SELECT date_format(MIN(create_time),'yyyy-MM-dd HH') first_recharge_time, tuid,date_format(MIN(create_time),'yyyy-MM-dd') today
       |  FROM orders
       | WHERE status= 1 and fee>0
       |   and date(create_time)<= '${SparkEnv.today}'
       | GROUP BY tuid HAVING today='${SparkEnv.today}'
       |) t1 on t.uid= t1.tuid GROUP BY t1.first_recharge_time
     """.stripMargin

  /**
    * 首次充值距离注册天数分布
    */
  val first_recharge_distance_register=
    s"""
       |SELECT t.uid, t.ctime register_time, t1.min_create_time first_recharge_time, datediff(date(t1.min_create_time), date(t.ctime)) days
       |  FROM user t JOIN(
       |SELECT MIN(create_time) min_create_time, tuid
       |  FROM orders
       | WHERE status= 1
       |   and DATE(create_time)<= '${SparkEnv.today}'
       | GROUP BY tuid) t1 on t.uid= t1.tuid
       |   and date(t1.min_create_time)= '${SparkEnv.today}'
     """.stripMargin

  /**
    * 充值时间分布
    */
  val recharge_time_distributed =
    s"""
       |SELECT date_format(t3.create_time,'yyyy-MM-dd HH') recharge_date,t2.scope,COUNT(1) recharge_times FROM
       |(
       |    SELECT
       |    	CASE
       |        WHEN t1.recharge_amounts>0 and t1.recharge_amounts<=1000 THEN 0
       |        WHEN t1.recharge_amounts>1000 and t1.recharge_amounts<=10000 THEN 1
       |        WHEN t1.recharge_amounts>10000 and t1.recharge_amounts<=50000 THEN 2
       |        WHEN t1.recharge_amounts>50000 and t1.recharge_amounts<=100000 THEN 3
       |        WHEN t1.recharge_amounts>100000 THEN 4 ELSE -1 END scope,
       |    	t1.tuid
       |    FROM
       |    (
       |        SELECT tuid,SUM(price)/100 recharge_amounts FROM orders WHERE status =1 and fee>0 and date(create_time)<='${SparkEnv.today}' GROUP BY tuid
       |    ) t1
       |) t2 JOIN
       |(
       |SELECT * FROM orders WHERE status=1 and fee >0 and date(create_time)='${SparkEnv.today}'
       |) t3 on t2.tuid=t3.tuid GROUP BY date_format(t3.create_time,'yyyy-MM-dd HH'),t2.scope
     """.stripMargin
}
