package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by Administrator on 2017/6/16 0016.
  */
object RechargeSQL {

  /**
    * 小爱充值
    * 0:小爱、爱钻数、充值人数、充值次数、充值金额、arpu
    */
  val xiaoai_recharge =
    s"""
       |select 0 type,
       |       sum(t1.total_amount) recharge_diamonds,
       |       count(distinct(t1.uid)) recharge_users,
       |       count(1) recharge_times,
       |       sum(fee) /100 recharge_amounts,
       |       (sum(t1.price) /100/count(distinct(t1.uid))) arpu,
       |       max(date(t1.create_time)) stats_date
       |  from orders t1,
       |       user t2
       | where t1.uid= t2.uid
       |   and t1.status= 1
       |   and t1.fee> 0
       |   and t1.channel not in(4, 6, 1)
       |   and date(t1.create_time)= '${SparkEnv.today}'
       | group by date(t1.create_time)
     """.stripMargin

  /**
    * 云图充值
    * 1:云图、爱钻数、充值人数、充值次数、充值金额、arpu
    */
  val yuntu_recharge =
    s"""
       |select 1 type,
       |       sum(t1.total_amount) recharge_diamonds,
       |       count(distinct(t1.uid)) recharge_users,
       |       count(1) recharge_times,
       |       sum(fee) /100 recharge_amounts,
       |       (sum(t1.price) /100/count(distinct(t1.uid))) arpu,
       |       max(date(t1.create_time)) stats_date
       |  from orders t1,
       |       user t2
       | where t1.uid= t2.uid
       |   and t1.status= 1
       |   and t1.fee> 0
       |   and t1.channel= 4
       |   and date(t1.create_time)= '${SparkEnv.today}'
       | group by date(t1.create_time)
     """.stripMargin

  /**
    * a8充值
    * 2:小爱、爱钻数、充值人数、充值次数、充值金额、arpu
    */
  val a8_recharge =
    s"""
       |select 2 type,
       |       sum(t1.total_amount) recharge_diamonds,
       |       count(distinct(t1.uid)) recharge_users,
       |       count(1) recharge_times,
       |       sum(fee) /100 recharge_amounts,
       |       (sum(t1.price) /100/count(distinct(t1.uid))) arpu,
       |       max(date(t1.create_time)) stats_date
       |  from orders t1,
       |       user t2
       | where t1.uid= t2.uid
       |   and t1.status= 1
       |   and t1.fee> 0
       |   and t1.channel= 6
       |   and date(t1.create_time)= '${SparkEnv.today}'
       | group by date(t1.create_time)
     """.stripMargin

  /**
    * 微信公众号充值
    * 3:小爱、爱钻数、充值人数、充值次数、充值金额、arpu
    */
  val webchart_recharge =
    s"""
       |select 3 type,
       |       sum(t1.total_amount) recharge_diamonds,
       |       count(distinct(t1.uid)) recharge_users,
       |       count(1) recharge_times,
       |       sum(fee) /100 recharge_amounts,
       |       (sum(t1.price) /100/count(distinct(t1.uid))) arpu,
       |       max(date(t1.create_time)) stats_date
       |  from orders t1,
       |       user t2
       | where t1.uid= t2.uid
       |   and t1.status= 1
       |   and t1.fee> 0
       |   and t1.channel= 1
       |   and date(t1.create_time)= '${SparkEnv.today}'
       | group by date(t1.create_time)
     """.stripMargin

  /**
    * 每日充值来源，小爱、a8、云图、微信公众号
    */
  val recharge_app =
    s"""
       |$xiaoai_recharge
       |union all
       |$yuntu_recharge
       |union all
       |$a8_recharge
       |union all
       |$webchart_recharge
     """.stripMargin

  /**
    * 每日用户爱钻、充值统计
    * 总数、充值爱钻数、充值人数、充值次数、充值金额、arpu
    */
  val user_recharge =
    s"""
       |select sum(total_amount) recharge_diamonds,
       |       count(distinct(uid)) recharge_users,
       |       count(1) recharge_times,
       |       sum(price/100) recharge_amounts,
       |       sum(price/100) /count(distinct(uid)) arpu,
       |       max(date(create_time)) stats_date
       |  from orders
       | where status= 1
       |   and date(create_time)= '${SparkEnv.today}'
       | group by date(create_time)
     """.stripMargin

  /**
    * 后台管理员充值
    */
  val admin_recharge=
    s"""
       |SELECT COUNT(DISTINCT(uid)) recharge_users,
       |       COUNT(1) recharge_times,
       |       SUM(amount) recharge_diamonds,
       |       sum(case when amount=120000 then 10000
       |       when amount=240000 then 20000
       |       when amount=375000 then 30000
       |       when amount=650000 then 50000 else amount/10 end) recharge_amounts,
       |       '${SparkEnv.today}' stats_date
       |  FROM admin_pay_record
       | WHERE type= 1
       |   and date(ctime)= '${SparkEnv.today}'
     """.stripMargin

  /**
    * 每日用户送礼
    * 收礼类型0:直播间 1:私信、消耗爱钻数、送礼用户数、收礼主播数
    */
  val send_gift_diamonds =
    s"""
       |select type,
       |       sum(recv_exp) consume_diamonds,
       |       count(distinct(uid)) consume_users,
       |       count(distinct(tuid)) recv_anchors,
       |       max(date(ctime)) stats_date
       |  from gift_history
       | where date(ctime)= '${SparkEnv.today}'
       | group by date(ctime), type
     """.stripMargin

  /**
    * 每日爱豆兑换爱钻数
    * 爱钻、爱豆、用户数
    */
  val exchange_diamonds =
    s"""
       |select sum(amount) exchange_diamonds,
       |       sum(price) exchange_beans,
       |       count(distinct(uid)) exchange_users,
       |       max(date(ctime)) stats_date
       |  from exchange_history
       | where date(ctime)= '${SparkEnv.today}'
       | group by date(ctime)
     """.stripMargin

  /**
    * 每日总充值
    * 充值爱钻数、充值人数、充值次数、充值金额、送礼爱钻数、兑换爱钻数、兑换爱豆数、送礼用户数、收礼主播数、
    */
  val recharge_overview =
    s"""
       |select
       | t1.*,
       | t2.exchange_diamonds,t2.exchange_beans,t2.exchange_users,
       | t3.consume_diamonds,t3.consume_users,t3.recv_anchors,
       | ifnull(t4.recharge_amounts,0) large_amounts,
       | ifnull(t4.recharge_diamonds,0) large_diamonds
       |from
       |($user_recharge) t1
       |left join
       |($exchange_diamonds) t2 on t1.stats_date = t2.stats_date
       |left join
       |(
       |  select stats_date,sum(consume_diamonds) consume_diamonds,sum(consume_users) consume_users,sum(recv_anchors) recv_anchors
       |  from ($send_gift_diamonds) group by stats_date
       |) t3
       | on t1.stats_date = t3.stats_date
       |left join
       |($admin_recharge) t4 on t1.stats_date=t4.stats_date
     """.stripMargin

  /**
    * 每日充值各档位次数
    */
  val recharge_grade =
    s"""
       |SELECT '${SparkEnv.today}' stats_date,
       |       CASE WHEN t.price/100= 1 THEN 0
       |       WHEN t.price/100= 6 THEN 1
       |       WHEN t.price/100= 30 THEN 2
       |       WHEN t.price/100= 98 THEN 3
       |       WHEN t.price/100= 298 THEN 4
       |       WHEN t.price/100= 588 THEN 5
       |       WHEN t.price/100= 1598 THEN 6
       |       WHEN t.price/100= 3000 THEN 7
       |       WHEN t.price/100= 5000 THEN 8
       |       WHEN t.price/100= 10000 THEN 9
       |       WHEN t.price/100= 20000 THEN 10
       |       WHEN t.price/100= 30000 THEN 11
       |       WHEN t.price/100= 50000 THEN 12 else -1 END scope,
       |       t.price/100 amounts,
       |       t.recharge_times,
       |       t.recharge_users
       |  FROM(
       |SELECT price, COUNT(1) recharge_times, COUNT(DISTINCT(tuid)) recharge_users
       |  FROM orders
       | WHERE status= 1
       |   AND fee> 0
       |   AND DATE(create_time)= '${SparkEnv.today}'
       | GROUP BY price) t
     """.stripMargin

  val new_user =
    s"""
       |
     """.stripMargin


//  val TimeGrainSize = Seq(Array(30 * 60 * 1000, "30分钟", 0),
//  Array(60 * 60 * 1000, "1小时", 1),Array(60 * 60 * 3 * 1000, "3小时", 2),Array(60 * 60 * 6 * 1000, "6小时", 3),
//  Array(60 * 60 * 12 * 1000, "12小时", 4),Array(60 * 60 * 24 * 1000, "天", 5))
//
//  private val ONE_DAY_MILLISECOND = 24 * 60 * 60 * 1000
//
//  var end_time = s"${SparkEnv.today}"
//
//  for (grainSize <- TimeGrainSize) {
//
//    for(i <- 0 until ONE_DAY_MILLISECOND/grainSize(0).asInstanceOf){
//
//    }
//    end_time=grainSize(0).asInstanceOf
//  }
}
