package com.yuntu.stats.kafka

/**
  * Created by Administrator on 2017/6/14 0014.
  */
trait KafkaProperties {
  val zkConnect = "localhost:2181"
  val groupId = "group1"
  val topic = "topic1"
  val kafkaServerURL = "localhost"
  val kafkaServerPort = 9092
  val kafkaProducerBufferSize: Int = 64 * 1024
  val connectionTimeOut = 20000
  val reconnectInterval = 10000
  val topic2 = "topic2"
  val topic3 = "topic3"
  val clientId = "SimpleConsumerDemoClient"
}
