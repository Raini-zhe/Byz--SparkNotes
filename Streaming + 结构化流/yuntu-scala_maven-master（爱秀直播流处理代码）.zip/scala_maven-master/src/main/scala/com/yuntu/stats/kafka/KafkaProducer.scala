package com.yuntu.stats.kafka

/**
  * Created by Administrator on 2017/6/14 0014.
  */
class KafkaProducer {

}
