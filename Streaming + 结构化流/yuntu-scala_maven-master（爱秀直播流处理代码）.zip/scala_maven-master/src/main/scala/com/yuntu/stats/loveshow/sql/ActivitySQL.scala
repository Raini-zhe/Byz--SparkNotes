package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object ActivitySQL {
  /**
    * 卡片活动
    */
  val card_activity=
    s"""
       |SELECT
       |	'${SparkEnv.today}' stats_date,
       |	t1.type,
       |	ifnull(t2.live_anchors,0) live_anchors,
       |	ifnull(t2.live_times,0) live_times,
       |	ifnull(t2.duration,0) duration,
       |	ifnull(t2.duration,0)/ifnull(t2.live_anchors,1) avg_duration,
       |	ifnull(t3.recv_diamonds,0) recv_diamonds,
       |	ifnull(t3.recv_anchors,0) recv_anchors,
       |	ifnull(t3.recv_diamonds,0)/ifnull(t2.live_anchors,1) avg_recv_diamonds,
       |	ifnull(t4.register_user,0) register_user,
       |	ifnull(t4.reward,0) reward,
       |	ifnull(t4.finish_anchors,0) finish_anchors
       |FROM
       |(
       |    select '100' type
       |    union
       |    select '200' type
       |    union
       |    select '500' type
       |) t1 LEFT JOIN
       |(
       |    SELECT
       |        t1.type,COUNT(DISTINCT(t1.uid)) live_anchors, SUM(t2.live_times) live_times,SUM(t2.duration) duration
       |    FROM card_user t1 JOIN
       |    (
       |    SELECT
       |    uid,COUNT(1) live_times,
       |    sum(CASE WHEN date(etime) = date(ctime) THEN duration
       |             WHEN date(etime) > date(ctime) THEN floor(etime/1000-unix_timestamp('${SparkEnv.today} 00:00:00'))
       |             WHEN date(etime) < date(ctime) THEN floor(unix_timestamp(date_add('${SparkEnv.today}',1)) -ctime/1000) else 0 end) duration
       |    FROM live_room_history WHERE
       |        (date(ctime)= '${SparkEnv.today}' and date(etime)= '${SparkEnv.today}')
       |     or (date(ctime)= '${SparkEnv.today}' and date(etime)!= '${SparkEnv.today}')
       |     or (date(ctime)!= '${SparkEnv.today}' and date(etime)= '${SparkEnv.today}')
       |    GROUP BY uid
       |    ) t2 on t1.uid=t2.uid GROUP BY t1.type
       |)  t2 on t1.type=t2.type
       |LEFT JOIN
       |(
       |    SELECT
       |        t1.type,SUM(t2.recv_exp) recv_diamonds,COUNT(DISTINCT(t1.uid)) recv_anchors
       |    FROM card_user t1 JOIN gift_history t2 on t1.uid=t2.tuid and date(t2.ctime) ='${SparkEnv.today}' GROUP BY t1.type
       |) t3 on t1.type=t3.type
       |LEFT JOIN
       |(
       |	SELECT type,COUNT(1) register_user,SUM(reward) reward,SUM(if(status=4,1,0)) finish_anchors   FROM card_user WHERE date(ctime)='${SparkEnv.today}' GROUP BY type
       |) t4 on t1.type=t4.type
     """.stripMargin
}
