package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object LiveSQL {
  /**
    * 主播单次直播间峰值
    */
  val anchor_live_peak=
    s"""
       |select t.rid room_id,
       |       t.uid,
       |       date_format(t.ctime, 'yyyy-MM-dd HH:mm:ss') ctime,
       |       date_format(t.etime, 'yyyy-MM-dd HH:mm:ss') etime,
       |       date_format(t1.gmt_probe, 'yyyy-MM-dd HH:mm:ss') peak_time,
       |       t1.value1 peak_users,
       |       t2.nick_name,
       |       t2.tag,
       |       t2.identification
       |  from live_room_history t join user t2 on t.uid= t2.uid join online_stats t1 on t.rid= t1.room_id
       |   and t1.gmt_probe>= t.ctime
       |   and t1.gmt_probe<= t.etime
       |   and date(t.ctime)= '${SparkEnv.today}'
       |   and date(t1.gmt_probe)= '${SparkEnv.today}'
       |
       """.stripMargin

  /**
    * 平台所有直播间每分钟总人数
    */
  val platform_live_peak=
    s"""
       |SELECT value1 peak_users,date_format(gmt_probe,'yyyy-MM-dd HH:mm:ss') peak_time FROM online_stats WHERE date(gmt_probe) = '${SparkEnv.today}' AND room_id =-1
     """.stripMargin

  /**
    * 每日直播间开播人数、平均直播时间、平均收礼爱豆
    */
  var platform_live_avg=
    s"""
       |SELECT '${SparkEnv.today}' stats_date, COUNT(DISTINCT(t1.uid)) live_anchors,
       |	SUM(t3.recv_beans) recv_beans,
       |	scope,
       |	SUM(t3.recv_beans)/COUNT(DISTINCT(t1.uid)) avg_bean,
       |	SUM(t4.duration)/COUNT(DISTINCT(t1.uid)) avg_duration FROM
       |(
       |SELECT uid,
       |CASE WHEN recv_exp BETWEEN 0 	   and 20000 THEN 0
       |	 WHEN recv_exp BETWEEN 20000   and 100000 THEN 1
       |	 WHEN recv_exp BETWEEN 100001  and 200000 THEN 2
       |	 WHEN recv_exp BETWEEN 200001  and 500000 THEN 3
       |	 WHEN recv_exp BETWEEN 500001  and 1000000 THEN 4
       |	 WHEN recv_exp >= 1000001 THEN  5 ELSE -1 END scope
       |FROM user_info
       |) t1 JOIN user t2 ON t1.uid =t2.uid and t2.tag <> ''
       |JOIN
       |(
       |SELECT uid,count(1) live_anchors,
       |sum(CASE WHEN date(etime) = date(ctime) THEN duration
       |	 WHEN date(etime) > date(ctime) THEN floor(etime/1000-unix_timestamp('${SparkEnv.today} 00:00:00'))
       |	 WHEN date(etime) < date(ctime) THEN floor(unix_timestamp(date_add('${SparkEnv.today}', 1), 'yyyy-MM-dd') -ctime/1000) else 0 end) duration
       |  FROM live_room_history
       | WHERE (date(ctime)= '${SparkEnv.today}'
       |   and date(etime)= '${SparkEnv.today}')
       |    or(date(ctime)= '${SparkEnv.today}'
       |   and date(etime)!= '${SparkEnv.today}')
       |    or(date(ctime)!= '${SparkEnv.today}'
       |   and date(etime)= '${SparkEnv.today}')
       | GROUP BY uid
       |) t4 on t1.uid=t4.uid
       |LEFT JOIN
       |(
       |SELECT tuid uid,SUM(recv_exp) recv_beans FROM gift_history WHERE date(ctime) = '${SparkEnv.today}' GROUP BY tuid
       |) t3 on t1.uid=t3.uid
       |GROUP BY t1.scope
     """.stripMargin
}
