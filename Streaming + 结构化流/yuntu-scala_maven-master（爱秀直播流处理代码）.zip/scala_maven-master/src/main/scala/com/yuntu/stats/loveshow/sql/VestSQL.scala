package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object VestSQL {
  /**
    * 马甲充值金额
    */
  val vest_recharge=
    s"""
       |SELECT COUNT(DISTINCT(tuid)) recharge_users,
       |       SUM(price)/100 recharge_amounts,
       |       count(1) recharge_times,
       |       app,
       |       term,
       |       '${SparkEnv.today}' stats_date
       |  FROM orders
       | WHERE status= 1
       |   AND fee> 0
       |   AND date(create_time)='${SparkEnv.today}'
       | GROUP BY app,term
       | ORDER BY app DESC
     """.stripMargin

  /**
    * 充值马甲
    */
  val vest_recharge_all=
    s"""
       |select app vest_code from orders group by app
     """.stripMargin

  /**
    * 注册马甲
    */
  val vest_register_all=
    s"""
       |select app vest_code from user group by app
     """.stripMargin

  val abc=
    s"""
       |select app,term from user group by app,term order by app,term desc
     """.stripMargin
}
