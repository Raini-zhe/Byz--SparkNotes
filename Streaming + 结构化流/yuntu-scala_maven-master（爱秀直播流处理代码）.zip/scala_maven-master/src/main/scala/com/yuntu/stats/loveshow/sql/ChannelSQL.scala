package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object ChannelSQL {
  val channel_all=
    s"""
       |select if(channel='','apple',channel) channel,'${SparkEnv.today}' stats_date from user group by channel
     """.stripMargin

  /**
    * 每日渠道新增用户
    */
  val channel_new_register_users =
    s"""
       |SELECT if(channel='','apple',channel) channel,COUNT(1) new_register_users FROM user WHERE date(ctime)= '${SparkEnv.today}' GROUP BY channel
     """.stripMargin

  /**
    * 每日渠道新增充值用户
    *
    */
  val channel_new_recharge_users =
    s"""
       |SELECT Count(DISTINCT(t1.uid)) new_recharge_users,
       |     SUM(t1.price)/100 new_recharge_amounts,
       |	   SUM((CASE WHEN datediff(date(t2.min_create_time), date(t1.ctime))= 0 THEN 1 ELSE 0 END)) new_register_recharge_users,
       |     SUM((CASE WHEN datediff(date(t2.min_create_time), date(t1.ctime))!= 0 THEN 1 ELSE 0 END)) old_register_recharge_users,
       |	   SUM((CASE WHEN datediff(date(t2.min_create_time), date(t1.ctime))= 0 THEN t1.price ELSE 0 END))/100 new_register_users_recharge_amounts,
       |     SUM((CASE WHEN datediff(date(t2.min_create_time), date(t1.ctime))!= 0 THEN t1.price ELSE 0 END))/100 old_register_user_recharge_amounts,
       |	   if(t1.channel='','apple',t1.channel) channel
       |FROM
       |(
       |SELECT max(t1.ctime) ctime,
       |       t1.uid,
       |       max(t1.channel) channel,
       |       sum(t2.price) price
       |  FROM user t1 JOIN orders t2 on t1.uid= t2.tuid
       |   and date(t2.create_time)= '2017-05-16'
       |   and t2.status= 1
       |   and t2.fee> 0 GROUP BY t1.uid
       |) t1
       |JOIN
       |(
       |SELECT MIN(create_time) min_create_time,
       |       tuid
       |  FROM orders
       | WHERE status= 1
       |   and fee > 0
       |   and DATE(create_time)<= '2017-05-16'
       | GROUP BY tuid
       |HAVING date(min_create_time)= '2017-05-16'
       |) t2 ON t1.uid=t2.tuid GROUP BY t1.channel
     """.stripMargin

  /**
    * 每日渠道充值情况
    * 充值人数、充值次数、充值金额
    */
  val channel_recharge =
    s"""
       |SELECT if(t1.channel='','apple',t1.channel) channel,
       |       COUNT(DISTINCT(t1.uid)) recharge_users,
       |       SUM(t2.price)/100 recharge_amounts,
       |       SUM(t2.total_amount) recharge_diamonds,
       |       COUNT(1) recharge_times,
       |       t2.term
       |  FROM user t1 JOIN orders t2 ON t1.uid= t2.tuid
       |   and t2.status= 1
       |   and t2.fee> 0
       |   and date(t2.create_time) = '${SparkEnv.today}'
       | GROUP BY t1.channel,t2.term
     """.stripMargin
}
