package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * Created by liss on 17-6-17.
  */
object AnchorSQL {
  /**
    * 每日Top收礼主播
    * 主播ID、收礼爱豆、送礼用户人数、统计日期、注册日期、昵称、anchor_type
    */
  val top_receive_gift_anchor=
    s"""
       |SELECT t1.*,
       |       t2.live_durations,
       |       date(t.ctime) ctime,
       |       t.nick_name,
       |       CASE WHEN t.ctag= '签约' THEN 2 WHEN t.ctag= 'v' THEN 3 WHEN t.ctag= '认证'
       |   AND t.identification= '' THEN 4 WHEN t.ctag= '认证'
       |   AND t.identification!= '' THEN 5 ELSE -1 END anchor_type
       |  FROM user t JOIN(
       |SELECT tuid uid, SUM(recv_exp) recv_beans, COUNT(DISTINCT(uid)) consume_users, max(DATE(ctime)) stats_date
       |  FROM gift_history
       | WHERE DATE(ctime)= '${SparkEnv.today}'
       | GROUP BY DATE(ctime), tuid
       | ORDER BY stats_date, recv_beans DESC
       | LIMIT 100) t1 ON t.uid= t1.uid JOIN(
       |SELECT uid, SUM(CASE WHEN date(etime)= date(ctime) THEN duration WHEN date(etime)> date(ctime) THEN floor(etime/1000-unix_timestamp('${SparkEnv.today} 00:00:00')) WHEN date(etime)< date(ctime) THEN floor(unix_timestamp(date_add('${SparkEnv.today}', 1), 'yyyy-MM-dd') -ctime/1000) END) live_durations
       |  FROM live_room_history
       | WHERE(date(ctime)= '${SparkEnv.today}'
       |   and DATE(etime)= '${SparkEnv.today}')
       |    or(date(ctime)= '${SparkEnv.today}'
       |   and DATE(etime)!= '${SparkEnv.today}')
       |    or(date(ctime)!= '${SparkEnv.today}'
       |   and DATE(etime)= '${SparkEnv.today}')
       | GROUP BY uid) t2 ON t1.uid= t2.uid
    """.stripMargin


  /**
    * SELECT uid,0 anchor_type  FROM user where ctag<>'' and ctag = 'v'
UNION
SELECT uid,0 anchor_type  FROM user where ctag<>'' and ctag = 'v+'
UNION
SELECT uid,0 anchor_type  FROM user where ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification like '%家族%' and cidentification like '%半月%'
UNION
SELECT uid,1 anchor_type  FROM user where ctag<>'' and ctag = '签约'
UNION
SELECT uid,1 anchor_type  FROM user where ctag<>'' and ctag = '签约+'
UNION
SELECT uid,1 anchor_type  FROM user where ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification not like '%家族%' and cidentification like '%半月%'
UNION
SELECT uid,2 anchor_type  FROM user where ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification like '%家族%' and cidentification not like '%半月%'
UNION
SELECT uid,3 anchor_type  FROM user where ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification not like '%家族%' and cidentification not like '%半月%'
    */
  /**
    * 每日主播开播人数,开播类型
    */
  val live_anchor=
    s"""
       |SELECT '${SparkEnv.today}' stats_date,count(distinct(t.uid)) live_anchors,sum(if(t2.tuid is not null,1,0)) recv_anchors,t.anchor_type,sum(ifnull(t2.recv_beans,0)) recv_beans,
       | sum(t1.duration) live_duration FROM
       |(
       |SELECT uid,3 anchor_type FROM user WHERE cidentification like '%站内%' and cidentification not like '%平台签约%'
       |UNION
       |SELECT uid,3 anchor_type FROM user WHERE cidentification = '' and ctag ='认证'
       |UNION
       |SELECT uid,0 anchor_type FROM user WHERE cidentification like '%家族%半月%'
       |UNION
       |SELECT uid,1 anchor_type FROM user WHERE cidentification like '%平台签约%'
       |UNION
       |SELECT uid,2 anchor_type FROM user WHERE cidentification like '%家族无底薪%'
       |) t
       |join
       |(
       |SELECT uid,SUM(duration) duration FROM live_room_history
       |  WHERE (date(ctime)='${SparkEnv.today}' and date(etime)='${SparkEnv.today}')
       |  or (date(ctime)='${SparkEnv.today}' and date(etime)!='${SparkEnv.today}')
       |  or (date(ctime)!='${SparkEnv.today}' and date(etime)='${SparkEnv.today}')
       |  GROUP BY uid having duration > 60*10
       |) t1 on t.uid=t1.uid
       |left join
       |(
       |SELECT tuid,SUM(recv_exp) recv_beans FROM gift_history WHERE date(ctime) = '${SparkEnv.today}' GROUP BY tuid
       |) t2 on t1.uid=t2.tuid group by t.anchor_type
       """.stripMargin

  /**
    * SELECT uid,0 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag = 'v'
UNION
SELECT uid,0 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag = 'v+'
UNION
SELECT uid,0 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification like '%家族%' and cidentification like '%半月%'
UNION
SELECT uid,1 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag = '签约'
UNION
SELECT uid,1 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag = '签约+'
UNION
SELECT uid,1 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification not like '%家族%' and cidentification like '%半月%'
UNION
SELECT uid,2 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification like '%家族%' and cidentification not like '%半月%'
UNION
SELECT uid,3 anchor_type  FROM user where date_add(date(ctime),30) >= '${SparkEnv.today}' and ctag<>'' and ctag !='v' and ctag !='v+' and ctag !='签约' and ctag !='签约+' and cidentification not like '%家族%' and cidentification not like '%半月%'
    */

  /**
    * 增加新主播开播人数统计
    * 新主播的筛选条件是注册未满30天（含30天）
    */
  val new_live_anchor=
    s"""
       |SELECT '${SparkEnv.today}' stats_date,count(distinct(t.uid)) live_anchors,sum(if(t2.tuid is not null,1,0)) recv_anchors,t.anchor_type,sum(ifnull(t2.recv_beans,0)) recv_beans,
       | sum(t1.duration) live_duration FROM
       |(
       |SELECT uid,3 anchor_type FROM user WHERE date_add(date(ctime),30) >= '${SparkEnv.today}' and cidentification like '%站内%' and cidentification not like '%平台签约%'
       |UNION
       |SELECT uid,3 anchor_type FROM user WHERE date_add(date(ctime),30) >= '${SparkEnv.today}' and cidentification = '' and ctag ='认证'
       |UNION
       |SELECT uid,0 anchor_type FROM user WHERE date_add(date(ctime),30) >= '${SparkEnv.today}' and cidentification like '%家族%半月%'
       |UNION
       |SELECT uid,1 anchor_type FROM user WHERE date_add(date(ctime),30) >= '${SparkEnv.today}' and cidentification like '%平台签约%'
       |UNION
       |SELECT uid,2 anchor_type FROM user WHERE date_add(date(ctime),30) >= '${SparkEnv.today}' and cidentification like '%家族无底薪%'
       |) t
       |join
       |(
       |SELECT uid,SUM(duration) duration FROM live_room_history
       |  WHERE (date(ctime)='${SparkEnv.today}' and date(etime)='${SparkEnv.today}')
       |  or (date(ctime)='${SparkEnv.today}' and date(etime)!='${SparkEnv.today}')
       |  or (date(ctime)!='${SparkEnv.today}' and date(etime)='${SparkEnv.today}')
       |  GROUP BY uid having duration > 60*10
       |) t1 on t.uid=t1.uid
       |left join
       |(
       |SELECT tuid,SUM(recv_exp) recv_beans FROM gift_history WHERE date(ctime) = '${SparkEnv.today}' GROUP BY tuid
       |) t2 on t1.uid=t2.tuid group by t.anchor_type
       """.stripMargin

  /**
    * 直播间人数 百分位数
    */
  val percentile =
    s"""
       |select
       |  max(case when t5.percent_type=0 then t5.value1 end) percent25,
       |  max(case when t5.percent_type=1 then t5.value1 end) percent50,
       |  max(case when t5.percent_type=2 then t5.value1 end) percent75,
       |  t5.room_id
       |from
       |(
       |select
       |    case when t4.row_number = if(0.25*t4.total_number<1,1,ceil(0.25*t4.total_number)) then 0
       |    when t4.row_number = if(0.50*t4.total_number<1,1,ceil(0.50*t4.total_number)) then 1
       |    when t4.row_number = if(0.75*t4.total_number<1,1,ceil(0.75*t4.total_number)) then 2
       |    else -1 end percent_type,
       |    round(t4.row_number/t4.total_number,2) percentile,t4.row_number,t4.total_number,t4.value1,t4.room_id from
       |(
       |SELECT room_id,value1,
       |  row_number() OVER (PARTITION BY room_id ORDER BY value1 ASC) as row_number,
       |  count(room_id) OVER (PARTITION BY room_id) as total_number
       |FROM
       |(
       |SELECT rid,MIN(ctime) min_ctime FROM live_room_history WHERE date(etime)='${SparkEnv.today}' GROUP BY rid
       |) t1
       |JOIN
       |(
       |SELECT rid,MAX(etime) max_etime FROM live_room_history WHERE date(etime)='${SparkEnv.today}' GROUP BY rid
       |) t2 on t1.rid=t2.rid
       |JOIN
       |online_stats t3 on t2.rid=t3.room_id where t3.gmt_probe>=t1.min_ctime and t3.gmt_probe<=t2.max_etime
       |) t4
       |) t5 where t5.percent_type!=-1 group by t5.room_id having count(t5.room_id)>=3
     """.stripMargin

  /**
    * 主播直播质量
    * 每日直播时长，收礼爱豆，新增粉丝，平均每分钟收礼爱豆
    */
  val anchor_quality =
    s"""
       |SELECT
       |  '${SparkEnv.today}' stats_date,t1.uid,t1.rid,t1.fans,t2.beans,t1.durations,t3.ctag,t3.cidentification,t3.nick_name,
       |  t4.percent25,t4.percent50,t4.percent75
       |FROM
       |(
       |SELECT uid,rid,SUM(duration) durations,SUM(fan_cnt) fans FROM live_room_history WHERE date(etime) = '${SparkEnv.today}' GROUP BY uid,rid
       |) t1
       |JOIN
       |(
       |SELECT tuid,SUM(recv_exp) beans FROM gift_history WHERE date(ctime) = '${SparkEnv.today}' GROUP BY tuid
       |) t2 on t1.uid=t2.tuid JOIN user t3 on t2.tuid=t3.uid and t3.ctag <> ''
       |LEFT JOIN (${percentile}) t4 on t1.rid=t4.room_id
     """.stripMargin
}
