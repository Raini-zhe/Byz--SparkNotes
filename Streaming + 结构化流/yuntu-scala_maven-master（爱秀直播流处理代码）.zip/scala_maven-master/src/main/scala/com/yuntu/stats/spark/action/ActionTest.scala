package com.yuntu.stats.spark.action

import org.apache.spark.sql.SparkSession

/**
  * Created by Administrator on 2017/6/13 0013.
  */
object ActionTest extends App{
  private val sparkSession = SparkSession.builder().master("local[*]").appName("ActionTest").getOrCreate()
  private val rdd = sparkSession.sparkContext.parallelize(Seq("hello world","hello spark","hello hive","hello scala","hello java"))

  /**
    * map函数会对每一条输入进行指定的操作，然后为每一条输入返回一个对象
    */
  private val map = rdd.map(_*2)
  map.foreach(println)

  /**
    * flatMap函数则是两个操作的集合——正是“先映射后扁平化”：
    * 操作1：同map函数一样：对每一条输入进行指定的操作，然后为每一条输入返回一个对象
    * 操作2：最后将所有对象合并为一个对象
    */
  private val flatMap = rdd.flatMap(x => x.split("\\s+"))
  flatMap.foreach(println)

  println("默认分区："+rdd.partitions.size)
  val rdd1 = rdd.coalesce(2);
  println("执行 coalesce 后分区分区："+rdd1.partitions.size)
}
