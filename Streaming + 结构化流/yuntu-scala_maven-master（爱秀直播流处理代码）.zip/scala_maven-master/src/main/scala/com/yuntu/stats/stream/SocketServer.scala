package com.yuntu.stats.stream

import java.net._
import java.io._
import scala.io._

/**
  * Created by Administrator on 2017/6/13 0013.
  */
object SocketServer extends App{
  val server = new ServerSocket(9999)
  while (true) {
    val s = server.accept()
    val in = new BufferedSource(s.getInputStream()).getLines()
    val out = new PrintStream(s.getOutputStream())

    out.println(in.next())
    out.flush()
    s.close()
  }
}
