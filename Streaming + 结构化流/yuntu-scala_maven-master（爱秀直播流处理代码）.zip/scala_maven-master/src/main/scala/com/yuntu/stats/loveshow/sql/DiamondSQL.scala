package com.yuntu.stats.loveshow.sql

/**
  * Created by liss on 17-6-17.
  */
object DiamondSQL {

}
