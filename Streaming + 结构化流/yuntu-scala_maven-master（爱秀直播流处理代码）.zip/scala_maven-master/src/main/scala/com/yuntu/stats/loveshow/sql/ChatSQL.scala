package com.yuntu.stats.loveshow.sql

import com.yuntu.stats.loveshow.SparkEnv

/**
  * 聊天
  * Created by liss on 17-6-17.
  */
object ChatSQL {
  /**
    * 根据用户累计充值金额分类统计私信和直播间聊天
    */
  val chat_recharge=
    s"""
       |SELECT
       |  '${SparkEnv.today}' stats_date,
       |  COUNT(t5.conversation_from_account) conversation_chart_users,
       |  SUM(t5.conversation_chart_times) conversation_chart_times,
       |  COUNT(t5.room_from_account) room_chart_uesrs,
       |  SUM(t5.room_chart_times) room_chart_times,
       |  t5.scope
       |FROM
       |(
       |SELECT
       |	t1.uid ,
       |	CASE WHEN t2.recharge_amounts>0 and t2.recharge_amounts<=1000 THEN 0
       |	WHEN t2.recharge_amounts>1000 and t2.recharge_amounts<=10000 THEN 1
       |	WHEN t2.recharge_amounts>10000 and t2.recharge_amounts<=50000 THEN 2
       |	WHEN t2.recharge_amounts>50000 and t2.recharge_amounts<=100000 THEN 3
       |	WHEN t2.recharge_amounts>100000 THEN 4 ELSE -1 END scope,
       |  t3.from_account conversation_from_account,
       |	t3.conversation_chart_times,
       |	t4.from_account room_from_account,
       |	t4.room_chart_times,
       |  t4.room_nums
       |FROM user t1 LEFT JOIN
       |(
       |	SELECT SUM(price)/100 recharge_amounts,tuid ,COUNT(1) recharge_times FROM orders WHERE date(create_time) <='${SparkEnv.today}' and status=1 and fee>0 GROUP BY tuid
       |) t2 on t1.uid=t2.tuid LEFT JOIN
       |(
       |  SELECT from_account,
       |         COUNT(1) conversation_chart_times
       |    FROM conversation_chat_record
       |   WHERE from_account!= '50e9fedebf094990a601d243a278e4c0'
       |     and from_account!= '1faa41d9af7844ecb9ebf119eddf219c'
       |     and from_account!= '7a6796d04f734ef39551c5a53aa00332'
       |     and date(msg_timestamp)= '${SparkEnv.today}'
       |   GROUP BY from_account
       |) t3 on t1.net_id=t3.from_account LEFT JOIN
       |(
       |  SELECT COUNT(1) room_chart_times,
       |         from_account,
       |         COUNT(DISTINCT(room_id)) room_nums
       |    FROM room_chat_record
       |   WHERE from_account!= '50e9fedebf094990a601d243a278e4c0'
       |     and from_account!= '1faa41d9af7844ecb9ebf119eddf219c'
       |     and from_account!= '7a6796d04f734ef39551c5a53aa00332'
       |     and date(msg_timestamp)= '${SparkEnv.today}'
       |   GROUP BY from_account
       |) t4 on t1.net_id=t4.from_account
       |) t5 GROUP BY t5.scope
     """.stripMargin

  val chat_room =
    s"""
       |SELECT
       |  COUNT(DISTINCT(t4.room_id)) room_nums,
       |  t3.scope
       |FROM
       |(
       |SELECT
       |	t1.uid,
       |  t1.net_id,
       |	CASE WHEN t2.recharge_amounts>0 and t2.recharge_amounts<=1000 THEN 0
       |	WHEN t2.recharge_amounts>1000 and t2.recharge_amounts<=10000 THEN 1
       |	WHEN t2.recharge_amounts>10000 and t2.recharge_amounts<=50000 THEN 2
       |	WHEN t2.recharge_amounts>50000 and t2.recharge_amounts<=100000 THEN 3
       |	WHEN t2.recharge_amounts>100000 THEN 4 ELSE -1 END scope
       |FROM user t1 LEFT JOIN
       |(
       |	SELECT SUM(price)/100 recharge_amounts,tuid ,COUNT(1) recharge_times FROM orders WHERE date(create_time) <='${SparkEnv.today}' and status=1 and fee>0 GROUP BY tuid
       |) t2 on t1.uid=t2.tuid
       |) t3 join (
       |  SELECT from_account,
       |	   room_id
       |  FROM room_chat_record
       | WHERE from_account!= '50e9fedebf094990a601d243a278e4c0'
       |   and from_account!= '1faa41d9af7844ecb9ebf119eddf219c'
       |   and from_account!= '7a6796d04f734ef39551c5a53aa00332'
       |   and date(msg_timestamp)= '${SparkEnv.today}'
       |) t4 on t3.net_id=t4.from_account GROUP BY t3.scope
     """.stripMargin

  val abc =
    s"""
       |select t3.*,sum(t3.exp) over(partition by t3.ctime) total_exp from
       |(
       |select
       |  rank() over(partition by t2.ctime order by exp desc) rank,
       |  t2.tuid,
       |  t2.ctime,
       |  t2.exp
       | from
       |(
       | SELECT
       |  max(date_format(t1.`ctime`,'yyyy-MM-dd HH')) ctime,
       |  SUM(t1.`recv_exp`) exp,
       |  t1.tuid
       | FROM
       |(
       |SELECT * FROM `gift_history` WHERE date(`ctime`) >='2017-05-17' and date(`ctime`) <='2017-07-17' and date_format(`ctime`,'HH')>=19 and date_format(`ctime`,'HH')<=23
       |union
       |SELECT * FROM `gift_history` WHERE date(`ctime`) >='2017-05-17' and date(`ctime`) <='2017-07-17' and date_format(`ctime`,'HH')>=00 and date_format(`ctime`,'HH')<=01
       |) t1
       |GROUP BY date_format(t1.`ctime`,'yyyy-MM-dd HH'),t1.tuid
       |) t2
       |) t3 where t3.rank<=10 order by t3.ctime,t3.rank
     """.stripMargin
}
