package com.yuntu.stats.utils

import java.io.FileInputStream
import java.sql.{Connection, DriverManager}
import java.util.Properties

/**
  * Created by Administrator on 2017/5/23 0023.
  */
object JdbcConfig {
  val XAZB = "xazb"

  val STATS_OP = "stats_op"

  def connectionProperties(suffix: String): Properties = {
    val prop = new Properties
    val props = loadProperties("jdbc.properties")
    prop.put("user", props.getProperty(suffix + ".user"))
    prop.put("password", props.getProperty(suffix + ".password"))
    prop.put("driver", props.getProperty(suffix + ".driver"))
    prop
  }

  def connectionURL(suffix: String): String = loadProperties("jdbc.properties").getProperty(suffix + ".url")

  def loadProperties(filePath:String) ={
    try {
      val prop = new Properties()
      prop.load(this.getClass.getClassLoader.getResourceAsStream(filePath))
      prop
    } catch { case e: Exception =>
      e.printStackTrace()
      sys.exit(1)
    }
  }

  def connectionInstance(suffix: String): Connection ={
    val props = loadProperties("jdbc.properties")
    Class.forName(props.getProperty(suffix + ".driver"))
    DriverManager.getConnection(props.getProperty(suffix + ".url") , props.getProperty(suffix + ".user") , props.getProperty(suffix + ".password") ) ;
  }
}
