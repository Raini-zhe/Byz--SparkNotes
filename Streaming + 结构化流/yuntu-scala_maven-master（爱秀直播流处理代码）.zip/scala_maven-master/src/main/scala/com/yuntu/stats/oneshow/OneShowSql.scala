package com.yuntu.stats.oneshow

/**
  * Created by Administrator on 2017/6/7 0007.
  */
object OneShowSql {

  /**
    * 主播数据
    */
  var anchor_data=
    s"""
       |SELECT t.uid,
       |         t2.call_times,
       |         t2.duration_total,
       |         t2.pay_total,
       |         IF(ISNULL(t1.recv_times), 0, t1.recv_times) recv_times,
       |         IF(ISNULL(t1.recv_exp), 0, t1.recv_exp) recv_exp
       |  FROM user t JOIN(
       |SELECT t.uid, count(1) call_times, SUM(t.duration) duration_total, SUM(t.pay) pay_total
       |  FROM live_room_history t
       | WHERE date(t.etime)= '${SparkTask.today}'
       | GROUP BY t.uid) t2 on t.uid= t2.uid
       |  LEFT JOIN(
       |SELECT t.tuid, SUM(t.recv_exp) recv_exp, COUNT(1) recv_times
       |  FROM gift_history t
       | WHERE date(t.ctime)= '${SparkTask.today}'
       | GROUP BY t.tuid) t1 on t1.tuid= t.uid
     """.stripMargin

  /**
    * 日通话总次数，日通话总时长，总发起人，总接收人
    */
  val duration_distributed =
    s"""
       |SELECT count(1) call_times_total,
       |       SUM(t.duration) call_duration_total,
       |       COUNT(DISTINCT(t.tuid)) send_users_total,
       |       COUNT(DISTINCT(t.uid)) recv_users_total,
       |       '${SparkTask.today}' stats_date
       |  FROM live_room_history t
       | where t.pay> 0
       |   and t.fee> 0
       |   and t.error_status= 0
       |   and date(t.etime)= '${SparkTask.today}'
       | group by date(t.etime)
     """.stripMargin

  /**
    * 次均通话时长分布
    */
  val per_times_distributed=
    s"""
       |SELECT t3.scope,
       |       count(t3.scope) call_times,
       |       '${SparkTask.today}' stats_date,
       |       count(DISTINCT t3.recv) recv_users,
       |       COUNT(DISTINCT t3.send) send_users
       |  FROM(
       |SELECT CASE WHEN t1.duration> 0 and t1.duration<= 60 THEN 0
       |      WHEN t1.duration> 60   and t1.duration<= 300  THEN 1
       |      WHEN t1.duration> 300  and t1.duration<= 600  THEN 2
       |      WHEN t1.duration> 600  and t1.duration<= 1200 THEN 3
       |      WHEN t1.duration> 1200 and t1.duration<= 1800 THEN 4
       |      WHEN t1.duration> 1800 and t1.duration<= 2400 THEN 5
       |      WHEN t1.duration> 2400 and t1.duration<= 3000 THEN 6
       |      WHEN t1.duration> 3000 and t1.duration<= 3600 THEN 7
       |      WHEN t1.duration> 3600 THEN 8 ELSE -1 END scope,
       |      t1.uid recv, t1.tuid send
       |  FROM(
       |SELECT t.duration, t.ctime, t.etime, t.pay, t.fee, t.uid, t.tuid
       |  FROM live_room_history t
       | WHERE t.pay> 0
       |   and fee> 0
       |   and t.error_status= 0) t1
       | WHERE date(t1.etime)= '${SparkTask.today}') t3
       | GROUP BY t3.scope
     """.stripMargin

  /**
    * 人均通话时长分布
    */
  val per_capita_distributed=
    s"""
       |SELECT t2.scope,
       |       count(t2.tuid) send_users,
       |       SUM(t2.call_times) call_times,
       |       '${SparkTask.today}' stats_date
       |  FROM(
       |SELECT CASE WHEN t1.duration> 0 and t1.duration<= 60 THEN 0
       |      WHEN t1.duration> 60    and t1.duration<= 300  THEN 1
       |      WHEN t1.duration> 300   and t1.duration<= 600  THEN 2
       |      WHEN t1.duration> 600   and t1.duration<= 1200 THEN 3
       |      WHEN t1.duration> 1200  and t1.duration<= 1800 THEN 4
       |      WHEN t1.duration> 1800  and t1.duration<= 2400 THEN 5
       |      WHEN t1.duration> 2400  and t1.duration<= 3000 THEN 6
       |      WHEN t1.duration> 3000  and t1.duration<= 3600 THEN 7
       |      WHEN t1.duration> 3600 THEN 8 ELSE -1 END scope,
       |      t1.tuid, t1.call_times
       |  FROM(
       |SELECT sum(t.duration) duration, t.tuid, COUNT(t.tuid) call_times
       |  FROM live_room_history t
       | WHERE t.pay> 0
       |   and fee> 0
       |   and t.error_status= 0
       |   and DATE(t.etime)= '${SparkTask.today}'
       | GROUP BY t.tuid) t1) t2
       | GROUP BY t2.scope
     """.stripMargin

  /**
    * 每天的请求次数,请求人数,请求主播数
    */
  val request_day=
    s"""
       |select '${SparkTask.today}' stats_date,
       |       count(1) request_times_total,
       |       count(distinct(uid)) request_users_total,
       |       count(distinct(tuid)) request_anchors_total
       |  from ask_room_history where date(ctime)='${SparkTask.today}'
       """.stripMargin

  /**
    * 主播被请求次数
    */
  val request_anchor=
    s"""
       |select '${SparkTask.today}' stats_date,
       |t.uid,
       |t.nick_name cnick_name,
       |CASE WHEN t.sign_tag!= '' THEN 2 WHEN t.sign_tag= '' AND t.tag!= '' THEN 1 ELSE 0 END type,
       |IF(t.tag= '', 0, 1) tag,
       |IF(t.sign_tag= '', 0, 1) sign_tag,
       |t1.request_times
       |from user t
       |join
       |(
       |select count(1) request_times,
       |       tuid uid
       |  from ask_room_history where date(ctime)='${SparkTask.today}'
       |  group by tuid
       |) t1 on t.uid=t1.uid
       """.stripMargin

  val anchor_detail_data=
    s"""
       |select
       | t1.*,
       | ifnull(t2.call_times,0) call_times,
       | ifnull(t2.duration_total,0) duration_total,
       | ifnull(t2.pay_total,0) pay_total,
       | ifnull(t2.recv_times,0) recv_times,
       | ifnull(t2.recv_exp,0) recv_exp
       |from (${request_anchor}) t1 left join (${anchor_data}) t2 on t1.uid=t2.uid
     """.stripMargin


  val abc =
    s"""
       |select '100' type
       |union
       |select '200' type
       |union
       |select '500' type
     """.stripMargin
}
