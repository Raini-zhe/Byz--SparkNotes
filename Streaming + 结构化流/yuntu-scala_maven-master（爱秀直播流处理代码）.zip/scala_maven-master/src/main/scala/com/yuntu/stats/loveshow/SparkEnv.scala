package com.yuntu.stats.loveshow

import java.sql.{Connection, PreparedStatement}

import com.yuntu.stats.config.Config
import com.yuntu.stats.config.Config.parser
import com.yuntu.stats.loveshow.sql._
import com.yuntu.stats.udf.UdfFunction
import com.yuntu.stats.utils.JdbcConfig
import org.apache.spark.sql.types.DataTypes._
import org.apache.spark.sql.types.{StructField, StructType}
import org.apache.spark.sql._
import org.slf4j.LoggerFactory

object SparkEnv {

  val log = LoggerFactory.getLogger(this.getClass)

  var today=""
  val today_day: String =  s"$today 23:59:59"
  val today_start: String = s"$today 00:00:00"

  def main(args: Array[String]): Unit = {

//    parser.parse(Seq("--debug","-p","C:\\Users\\Administrator\\Desktop\\loveshow\\","-c","2016-09-17","-t","csv"), Config()) match {
    parser.parse(args.toSeq, Config()) match {
      case Some(config) => {
        val sparkSession = if(config.debug){
          System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4");
          SparkSession.builder().master("local[1]").getOrCreate()
        } else {
          SparkSession.builder().getOrCreate()
        }
        today=config.currentDate
        defaultTable(sparkSession,config.hdfsPath)
        config.taskNames.foreach(executeTask(_,sparkSession,config.debug))
        log.error(config.toString)
        sparkSession.stop()
      }
      case None => log.error("args error")
    }
//    sparkSession.sql(sql1).repartition(1).write.options(Map("header"->"true","charset"->"utf-8")).csv("C:\\Users\\Administrator\\Desktop\\loveshow\\data.csv")
  }

  def executeTask(taskName:String,sparkSession: SparkSession,debug:Boolean)={
    UdfFunction(sparkSession);
    taskName match {
      case "csv" =>  sparkSession.sql(CsvSQL.wdc).repartition(1).write.options(Map("header"->"true","charset"->"utf-8","nullValue"->"")).csv("/home/hadoop/data.csv")
      case "chat_recharge" => sparkSession.sql(ChatSQL.chat_recharge).join(sparkSession.sql(ChatSQL.chat_room),Seq("scope"),"left_outer").toDF.coalesce(4).write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_chat_recharge", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      /**
        * 渠道
        */
      case "channel" => {
        val dataset = sparkSession.sql(ChannelSQL.channel_all)
          .join(sparkSession.sql("select gmt_create,gmt_modify,channel_code channel,channel_name,conf_group from channel"), Seq("channel"), "left_outer")
          .select(new Column("gmt_create"), new Column("gmt_modify"), new Column("channel").as("channel_code"), new Column("channel_name"), new Column("conf_group"))
          .coalesce(1)
        channelTranscation(dataset)
      }
      case "channel_new_user" => channelUserRechargeTask(sparkSession)
      case "channel_recharge" => sparkSession.sql(ChannelSQL.channel_all).join(sparkSession.sql(ChannelSQL.channel_recharge),"channel").
        coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_channel_recharge", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      /**
        * 主播
        */
      case "anchor_quality" => sparkSession.sql(AnchorSQL.anchor_quality).toDF.coalesce(4).write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_anchor_quality", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "live_anchor" => sparkSession.sql(AnchorSQL.live_anchor).toDF.coalesce(4).write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_live_anchor", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "new_live_anchor" => sparkSession.sql(AnchorSQL.new_live_anchor).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_new_live_anchor", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "top_receive_gift_anchor" =>sparkSession.sql(AnchorSQL.top_receive_gift_anchor).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_top_anchor", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      /**
        * 直播间
        */
      case "anchor_live_peak" =>anchorLivePeakTask(sparkSession)
      case "platform_live_peak" => sparkSession.sql(LiveSQL.platform_live_peak).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_platform_live_peak", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "platform_live_avg" => sparkSession.sql(LiveSQL.platform_live_avg).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_platform_live_avg", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      /**
        * 活动
        */
      case "card_activity" => if(debug) sparkSession.sql(ActivitySQL.card_activity).show(1000) else sparkSession.sql(ActivitySQL.card_activity).coalesce(4).toDF().write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_card_activity", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      /**
        * 马甲
        */
      case "vest_recharge" => sparkSession.sql(VestSQL.vest_recharge).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_vest_recharge", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "vest" => {
        val dataset = sparkSession.sql(VestSQL.vest_register_all)
          .join(sparkSession.sql("select gmt_create,gmt_modify,vest_code,vest_name,conf_group from vest"), Seq("vest_code"), "left_outer")
          .select(new Column("gmt_create"), new Column("gmt_modify"), new Column("vest_code"), new Column("vest_name"), new Column("conf_group"))
          .coalesce(1)
        vestTranscation(dataset)
      }
      /**
        * 礼物
        */
      case "top_gift_consume" =>sparkSession.sql(LoveShowSql.top_gift_consume).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_top_gift", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "gift_consume_snapshots" => sparkSession.sql(LoveShowSql.gift_consume_snapshots).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_gift_consume_snapshots", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      /**
        * 爱钻
        */
      case "user_remain_diamond" => sparkSession.sql(LoveShowSql.user_remain_diamond).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_user_remain_diamond", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))

      /**
        * 活跃用户
        */
      case "active_vest_user" => sparkSession.sql(ActiveSQL.active_vest_user).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_active_vest_user", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "active_channel_user" => sparkSession.sql(ActiveSQL.active_channel_user).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_active_channel_user", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "active_recharge_user" => sparkSession.sql(ActiveSQL.active_recharge_user).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_active_recharge_user", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "active_app_user" => sparkSession.sql(ActiveSQL.active_app_user).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_active_app_user", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))

      case "new_register_user_snapshots" => sparkSession.sql(LoveShowSql.new_register_user_snapshots).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_new_register_user_snapshots", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "new_user" =>sparkSession.sql(LoveShowSql.new_register_users).join(sparkSession.sql(LoveShowSql.new_recharge_users),"stats_date").coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_new_user", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "top_recharge_user" =>sparkSession.sql(LoveShowSql.top_recharge_user).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_top_recharge", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "top_consume_beans_user" =>sparkSession.sql(LoveShowSql.top_consume_beans_user).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_top_consume", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "user_accumulate_recharge" => sparkSession.sql(LoveShowSql.user_accumulate_recharge).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_user_accumulate_recharge", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "first_recharge_time" => sparkSession.sql(LoveShowSql.first_recharge_time).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_first_recharge_time", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "first_recharge_distance_register" => sparkSession.sql(LoveShowSql.first_recharge_distance_register).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_first_recharge_distance_register", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "recharge_time_distributed" => sparkSession.sql(LoveShowSql.recharge_time_distributed).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_recharge_time_distributed", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "recharge_app" => sparkSession.sql(RechargeSQL.recharge_app).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_recharge_app", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "recharge_overview" => sparkSession.sql(RechargeSQL.recharge_overview).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_recharge_overview", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "recharge_grade" => sparkSession.sql(RechargeSQL.recharge_grade).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_recharge_grade", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
      case "abc" => sparkSession.sql(ChatSQL.abc).show(1000)
      case _ if taskName!=null => log.error(s"no such task $taskName !")
      case _ => log.error(s"no such task $taskName !")
    }
  }
  def channelUserRechargeTask(sparkSession: SparkSession): Unit ={
    val dataFrame = sparkSession.sql(ChannelSQL.channel_all).join(sparkSession.sql(ChannelSQL.channel_new_register_users), Seq("channel"), "leftouter")
      .join(sparkSession.sql(ChannelSQL.channel_new_recharge_users), Seq("channel"), "leftouter")
    dataFrame.coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_channel_new_user", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
  }

  def vestTranscation(dataFrame: DataFrame): Unit ={
    dataFrame.foreachPartition{
      iter=> {
        val sql = "replace into vest(gmt_create,gmt_modify,vest_code,vest_name,conf_group) values(?,?,?,?,?)";
        var connection:Connection = null;
        var stmt:PreparedStatement = null;
        try{

          connection = JdbcConfig.connectionInstance(JdbcConfig.STATS_OP)
          connection.setAutoCommit(false)
          //              connection.prepareStatement(sql, iter.)
          iter.foreach { it =>
            stmt = connection.prepareStatement(sql)
            stmt.setTimestamp(1,it.getTimestamp(0))
            stmt.setTimestamp(2,it.getTimestamp(1))
            stmt.setString(3,it.getString(2))
            stmt.setString(4,if(it.getString(3)==null) it.getString(2) else it.getString(3))
            stmt.setString(5,it.getString(4))
            stmt.execute()
          }
          connection.commit()
        }catch {
          case e:Exception => e.printStackTrace();connection.rollback()
        } finally {
          if(connection!=null) connection.close()
          if(stmt!=null) stmt.close()
        }
      }
    }
  }

  def channelTranscation(dataFrame: DataFrame): Unit ={
    dataFrame.foreachPartition{
      iter=> {
        val sql = "replace into channel(gmt_create,gmt_modify,channel_code,channel_name,conf_group) values(?,?,?,?,?)";
        var connection:Connection = null;
        var stmt:PreparedStatement = null;
        try{
          connection = JdbcConfig.connectionInstance(JdbcConfig.STATS_OP)
          connection.setAutoCommit(false)
          //              connection.prepareStatement(sql, iter.)
          iter.foreach { it =>
            stmt = connection.prepareStatement(sql)
            stmt.setTimestamp(1,it.getTimestamp(0))
            stmt.setTimestamp(2,it.getTimestamp(1))
            stmt.setString(3,it.getString(2))
            stmt.setString(4,if(it.getString(3)==null) it.getString(2) else it.getString(3))
            stmt.setString(5,it.getString(4))
            stmt.execute()
          }
          connection.commit()
        }catch {
          case e:Exception => e.printStackTrace();connection.rollback()
        } finally {
          if(connection!=null) connection.close()
          if(stmt!=null) stmt.close()
        }
      }
    }
  }

  def anchorLivePeakTask(sparkSession: SparkSession): Unit ={
    val javaRDD = sparkSession.sql(LiveSQL.anchor_live_peak).rdd.map((r: Row) => {
      ((r.getAs[Int]("room_id"), r.getAs[Long]("ctime"), r.getAs[Long]("etime")), (r))
    }).reduceByKey((v1, v2) => {
      if (v1.getAs[Int]("peak_users") >= v2.getAs[Int]("peak_users")) v1 else v2
    }).values.toJavaRDD()

    sparkSession.createDataFrame(javaRDD,StructType(
      Array(
        StructField("room_id", LongType, nullable=false),
        StructField("uid", LongType, nullable=false),
        StructField("ctime", StringType, nullable=false),
        StructField("etime", StringType, nullable=false),
        StructField("peak_time", StringType, nullable=false),
        StructField("peak_users", IntegerType, nullable=false),
        StructField("nick_name", StringType, nullable=true),
        StructField("tag", StringType, nullable=true),
        StructField("identification", StringType, nullable=true)
      )
    )).coalesce(4).toDF.write.mode(SaveMode.Append).jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP), "loveshow_anchor_live_peak", JdbcConfig.connectionProperties(JdbcConfig.STATS_OP))
  }

  def defaultTable(sparkSession: SparkSession,path:String)={
    (
//      ("card_user","card_user/*.parquet"),
      ("gift_history","gift_history/*.parquet"),
      ("exchange_history","exchange_history/*.parquet"),
      ("gift_item","gift_item/*.parquet"),
      ("live_room_history","live_room_history/*.parquet"),
      ("orders","orders/*.parquet"),
//      ("send_award_record","send_award_record/*.parquet"),
//      ("admin_pay_record","admin_pay_record/*.parquet"),
//      ("online_stats","online_stats/*.parquet"),
      ("user","user/*.parquet"),
      ("user_info","user_info/*.parquet"),
//      ("withdraw_account","withdraw_account/*.parquet"),
//      ("live_room_day","live_room_day/*.parquet"),
//      ("income_history","income_history/*.parquet"),
//      ("room_chat_record","/im_sync/"),
//      ("channel","channel"),
//      ("vest","vest"),
      ("room_chat_record","room_chat_record"),
      ("conversation_chat_record","conversation_chat_record")
    ).productIterator.foreach(v => {
      v match{
        case ("room_chat_record",fileName:String) => sparkSession.sql("select * from parquet.`/im_syncdb/incremental_backup/room_chat_record/*parquet`").createOrReplaceTempView("room_chat_record")
        case ("conversation_chat_record",fileName:String) => sparkSession.sql("select * from parquet.`/im_syncdb/incremental_backup/conversation_chat_record/*.parquet`").createOrReplaceTempView("conversation_chat_record")
        case ("vest",fileName:String) => sparkSession.read.jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP),"vest",JdbcConfig.connectionProperties(JdbcConfig.STATS_OP)).createOrReplaceTempView(fileName)
        case ("channel",fileName:String) => sparkSession.read.jdbc(JdbcConfig.connectionURL(JdbcConfig.STATS_OP),"channel",JdbcConfig.connectionProperties(JdbcConfig.STATS_OP)).createOrReplaceTempView(fileName)
        case (tableName:String,fileName:String) => sparkSession.sql("select * from parquet.`"+path+ fileName +"`").createOrReplaceTempView(tableName)
        case _ => log.error(s"no such file ${v}")
      }
    })
  }
}
