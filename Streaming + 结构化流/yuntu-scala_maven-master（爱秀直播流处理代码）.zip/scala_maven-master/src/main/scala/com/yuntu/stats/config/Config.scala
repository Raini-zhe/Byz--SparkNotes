package com.yuntu.stats.config

/**
  * Created by Administrator on 2017/5/25 0025.
  */
case class Config(debug:Boolean = false,currentDate: String = "", startDate: String = "" , endDate: String = "",hdfsPath: String = "",taskNames: Seq[String] = Seq()){

}

object Config{

  val parser = new scopt.OptionParser[Config]("scopt") {
    head("scopt", "3.x")
    opt[Unit]("debug").action( (_, c) => c.copy(debug = true) ).text("this option is hidden in the usage text")
    opt[String]('c', "currentDate").action( (x, c) => c.copy(currentDate = x)).text("current is an string property")
    opt[String]('s', "startDate").action( (x, c) => c.copy(startDate = x)).text("startDate is an string property")
    opt[String]('e', "endDate").action( (x, c) => c.copy(endDate = x)).text("endDate is an string property")
    opt[String]('p', "hdfsPath").action( (x, c) => c.copy(hdfsPath = x)).text("hdfsPath is an string property")
    opt[Seq[String]]('t', "taskNames").valueName("<task1>,<task2>...").action( (x,c) => c.copy(taskNames = x) ).text("taskNames to include")
  }

}


