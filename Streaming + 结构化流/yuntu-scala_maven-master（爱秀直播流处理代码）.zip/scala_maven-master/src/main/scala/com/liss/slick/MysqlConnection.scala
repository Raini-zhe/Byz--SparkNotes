//package com.liss.slick
//
//import slick.jdbc.JdbcBackend._
//
//object MysqlConnection extends App with DatabaseFactoryDef{
//  val db = Database.forConfig("mysql")
//  val bean = new Bean
////  val setupFuture = db.run(new Bean().setup)
//  try {
//    val connection = db.source.createConnection()
//    val prepareStatement = connection.prepareStatement("select * from user")
//    val resultSet = prepareStatement.executeQuery()
//    if(resultSet.next()) println(resultSet.getRow)
//
//  } finally db.close
//}
