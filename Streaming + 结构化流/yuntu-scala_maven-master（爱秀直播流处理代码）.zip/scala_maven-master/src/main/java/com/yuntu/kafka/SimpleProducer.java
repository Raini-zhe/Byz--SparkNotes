//package com.yuntu.kafka;
//
//import org.apache.kafka.clients.producer.KafkaProducer;
//
//import org.apache.kafka.clients.producer.ProducerRecord;
//
//import java.util.Properties;
//
///**
// * Created by Administrator on 2017/6/14 0014.
// */
//public class SimpleProducer extends Thread {
//    private final KafkaProducer<String, String> producer;
//    private final String topic;
//    private final Properties props = new Properties();
//
//    public SimpleProducer(String topic) {
//        //Assign localhost id
//        props.put("bootstrap.servers", "localhost:9092");
//
//        //Set acknowledgements for producer requests.
//        props.put("acks", "all");
//
//        //If the request fails, the producer can automatically retry,
//        props.put("retries", 0);
//
//        //Specify buffer size in config
//        props.put("batch.size", 16384);
//
//        //Reduce the no of requests less than 0
//        props.put("linger.ms", 1);
//
//        //The buffer.memory controls the total amount of memory available to the producer for buffering.
//        props.put("buffer.memory", 33554432);
//
//        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
//
//        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
//        producer = new KafkaProducer<String, String>(props);
//        this.topic = topic;
//    }
//
//    @Override
//    public void run() {
//        int messageNo = 1;
//        while (true) {
//            String messageStr = new String("Message_" + messageNo);
//            producer.send(new ProducerRecord<String, String>(KafkaProperties.topic, messageStr, String.valueOf(messageNo)));
//            System.out.println("Send:" + messageStr);
//            messageNo++;
//            try {
//                sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
