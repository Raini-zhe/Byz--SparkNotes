//package com.yuntu.kafka;
//
///**
// * Created by Administrator on 2017/6/14 0014.
// */
//public class KafkaConsumerProducerDemo {
//    public static void main(String[] args) {
////        SimpleProducer producerThread = new SimpleProducer(KafkaProperties.topic);
////        producerThread.start();
//        SimpleConsumer consumerThread = new SimpleConsumer(KafkaProperties.topic);
//        consumerThread.start();
//    }
//}
