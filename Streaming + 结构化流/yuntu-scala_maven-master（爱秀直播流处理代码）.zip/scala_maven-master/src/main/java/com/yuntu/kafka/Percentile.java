package com.yuntu.kafka;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017/7/13 0013.
 */
public class Percentile {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        for(int i=1;i<101;i++){
            list.add(i);
        }
        Integer[] data = list.toArray(new Integer[0]);
        data = new Integer[]{5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,27,67, 68,69,70,71,72};
        System.out.println(percentile(data,0.50));
    }
    public static double percentile(Integer[] data,double p){
        int n = data.length;
        Arrays.sort(data);
        double px =  p*(n-1);
        int i = (int)java.lang.Math.floor(px);
        double g = px - i;
        if(g==0){
            return data[i];
        }else{
            return (1-g)*data[i]+g*data[i+1];
        }
    }

}
