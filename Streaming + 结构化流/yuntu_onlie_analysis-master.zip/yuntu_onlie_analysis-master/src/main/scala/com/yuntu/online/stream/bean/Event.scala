package com.yuntu.online.stream.bean

import com.fasterxml.jackson.annotation.JsonProperty

/**
  * Created by Administrator on 2017/6/27 0027.
  */
case class Event (
  /**
    * 渠道
    */
  var channel:String,

  /**
    * 手机型号
    */
  var model:String,

  /**
    * WiFi:0, 4G:1
    */
  var nettype:String,

  /**
    * 用户终端 0-android 1-ios
    */
  var term:String,

  var token:String,

  var ts:String,

  /**
    * 设备ID
    */
  var udid:String,

  var uid:String,

  /**
    * app 版本号，VersionCode
    */
  var version:String,

  @JsonProperty("data") var body:EventBody
){


}
