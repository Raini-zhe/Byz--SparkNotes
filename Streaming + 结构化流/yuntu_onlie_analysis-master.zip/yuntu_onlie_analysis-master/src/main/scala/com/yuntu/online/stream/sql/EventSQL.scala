package com.yuntu.online.stream.sql

/**
  * Created by Administrator on 2017/6/27 0027.
  * 维度
  * 全网
  * CDN维度
  * 域名
  * 房间 rid
  * ISP isp
  * 地区 location
  * 终端类型 term
  */
object EventSQL {
  /**
    * 视频卡顿
    */
  val  play_fault =
    s"""
       |select
       |  t1.*,
       |  sum(t1.online_users) over (partition by t1.sampling_time) as total_online_users
       |from
       |(
       |  select max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) sampling_time,
       |    count(distinct(uid)) online_users,
       |    count(1) fault_times,
       |    term,body.location,body.rid,body.isp,body.type
       |  from playEvent group by from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm'),term,body.location,body.rid,body.isp,body.type order by sampling_time desc
       |) t1
     """.stripMargin

  /**
    * 在线人数
    */
  val online_users =
    s"""
       |select
       |  max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) sampling_time,
       |  count(distinct(uid)) online_users,3 type
       |from playEvent where body.type=3 group by from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')
       |union
       |select
       |  max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) sampling_time,
       |  count(distinct(uid)) online_users, 0 type
       |from playEvent where body.type=0 group by from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')
     """.stripMargin

  /**
    * 主播在线数
    */
  val online_anchors =
    s"""
       |select max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) ts,
       |count(distinct(uid)) online_anchors
       | from heartbeatEvent group by from_unixtime(floor(ts/100),'yyyy-MM-dd HH:mm'),term,body.location,body.rid,body.isp
     """.stripMargin

  /**
    * 主播流数据
    * sampling_time,version,uid,stream,bps,
    */
  val anchor_stream =
    s"""
       |select ts sampling_time,
       |version,uid,
       |body.stream_url stream,
       |body.bps bps from streamEvent
     """.stripMargin

  /**
    * 推流详情
    */
  val stream_detail =
    s"""
       |select sampling_time,uid,isp,rid,channel,term,nettype,version,model,total_stream_times from
       |(
       |select from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm') sampling_time,
       |uid,
       |body.isp isp,
       |body.rid rid,
       |body.type type,
       |channel,
       |term,
       |nettype,
       |version,
       |model,
       |count(1) over() total_stream_times
       |from streamEvent
       |) t where t.type=1
     """.stripMargin

  /**
    * 推流细分维度
    */
  val stream_dimension =
    s"""
       |select
       |  t.ts sampling_time,
       |  t.rid,
       |  sum(t.stream_times) over(partition by ts,rid) as rid_stream_times,
       |  t.isp,
       |  sum(t.stream_times) over(partition by ts,isp) as isp_stream_times,
       |  t.channel,
       |  sum(t.stream_times) over(partition by ts,channel) as channel_stream_times,
       |  t.term,
       |  sum(t.stream_times) over(partition by ts,term) as term_stream_times,
       |  t.nettype,
       |  sum(t.stream_times) over(partition by ts,nettype) as nettype_stream_times,
       |  t.stream_times,
       |  sum(t.stream_times) over(partition by ts) as ts_stream_times,
       |  count(1) over() as total_stream_times
       |from
       |(
       |select max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) ts,
       |body.isp isp,
       |body.rid rid,
       |channel,
       |term,
       |nettype,
       |sum(case when body.type=1 then 1 else 0 end) stream_times
       |from streamEvent group by from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm'),body.isp,body.rid,channel,term,nettype
       |) t
     """.stripMargin

  /**
    * 推流总维度
    */
  val stream_dimension_total =
    s"""
       |select
       |  t1.ts sampling_time,
       |  sum(distinct(rid_stream_times)) rid_stream_times,
       |  sum(distinct(isp_stream_times)) isp_stream_times,
       |  sum(distinct(channel_stream_times)) channel_stream_times,
       |  sum(distinct(term_stream_times)) term_stream_times,
       |  sum(distinct(nettype_stream_times)) nettype_stream_times,
       |  sum(distinct(ts_stream_times)) ts_stream_times,
       |  sum(distinct(total_stream_times)) total_stream_times
       |from
       |(
       |select
       |  t.ts,
       |  sum(t.stream_times) over(partition by ts,rid) as rid_stream_times,
       |  sum(t.stream_times) over(partition by ts,isp) as isp_stream_times,
       |  sum(t.stream_times) over(partition by ts,channel) as channel_stream_times,
       |  sum(t.stream_times) over(partition by ts,term) as term_stream_times,
       |  sum(t.stream_times) over(partition by ts,nettype) as nettype_stream_times,
       |  sum(t.stream_times) over(partition by ts) as ts_stream_times,
       |  count(1) over() as total_stream_times
       |from
       |(
       |select max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) ts,
       |body.isp isp,
       |body.rid rid,
       |channel,
       |term,
       |nettype,
       |sum(case when body.type=1 then 1 else 0 end) stream_times
       |from streamEvent group by from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm'),body.isp,body.rid,channel,term,nettype
       |) t
       |) t1 group by t1.ts
     """.stripMargin

  val abc =
    s"""
       |select max(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')) ts,
       |sum(case when body.type=1 then 1 else 0 end) stream_times
       |from streamEvent group by from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm')
     """.stripMargin
}
