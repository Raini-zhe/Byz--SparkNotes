package com.yuntu.online.stream.transaction

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.typesafe.config.ConfigFactory
import com.yuntu.online.stream.bean.Event
import com.yuntu.online.stream.jdbc.SetupJdbc
import com.yuntu.online.stream.sql.EventSQL
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Assign
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.{CanCommitOffsets, HasOffsetRanges, KafkaUtils, OffsetRange}
import org.apache.spark.{SparkConf, TaskContext}
import scalikejdbc._

/**
  * Created by Administrator on 2017/6/22 0022.
  */
object SparkStreamQuality {
  var  dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:00")
  val calendar = Calendar.getInstance

  val checkpointDirectory = "D:\\chk_streaming"

  val mapper = new ObjectMapper()

  def main(args: Array[String]): Unit = {
    mapper.registerModule(DefaultScalaModule)
    System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4")
    val conf = ConfigFactory.load
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> conf.getString("kafka.brokers"),
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "1",
      "enable.auto.commit" -> (false: java.lang.Boolean),
      "auto.offset.reset" -> "none"
    )

    val jdbcDriver = conf.getString("jdbc.driver")
    val jdbcUrl = conf.getString("jdbc.url")
    val jdbcUser = conf.getString("jdbc.user")
    val jdbcPassword = conf.getString("jdbc.password")

    val ssc = setupSsc(kafkaParams, jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)()
    ssc.start()
    ssc.awaitTermination()
  }

  def setupSsc(kafkaParams: Map[String, Object],
               jdbcDriver: String,
               jdbcUrl: String,
               jdbcUser: String,
               jdbcPassword: String
              )(): StreamingContext = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("SparkStreamQuality")

    val ssc = new StreamingContext(conf, Seconds(10))

    SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)

    // begin from the the offsets committed to the database
    val fromOffsets = DB.readOnly { implicit session =>
      sql"select topic, part, offset from kafka_offsets WHERE topic ='streamEvent'".
        map { resultSet =>
          new TopicPartition(resultSet.string(1), resultSet.int(2)) -> resultSet.long(3)
        }.list.apply().toMap
    }

    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      Assign[String, String](fromOffsets.keys.toList, kafkaParams, fromOffsets)
    )

    stream.foreachRDD { rdd => {
      SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)
      val map = rdd.map {
        record => mapper.readValue(record.value(), classOf[Event])
      }
      val spark = SparkSession.builder().config(conf).getOrCreate()
      import spark.implicits._

      val current = dateFormat.format(new Date)
      map.filter{event =>
        calendar.setTimeInMillis(event.ts.toLong)
        dateFormat.format(calendar.getTime)<current
      }.toDF().cache().createOrReplaceTempView("streamEvent")

      val partitionIndex = extractPartitionIndex(map,current)
      val stream_detail = spark.sql(EventSQL.stream_detail).rdd.map(row => row.toSeq).collect();
      val stream_dimension = spark.sql(EventSQL.stream_dimension).rdd.map(row => row.toSeq).collect();
      val stream_dimension_total = spark.sql(EventSQL.stream_dimension_total).rdd.map(row => row.toSeq).collect();

      DB.localTx { implicit session =>
        sql"""
               INSERT INTO loveshow_online_stream_detail (sampling_time,uid,isp,rid,channel,term,nettype,version,model,total_stream_times) VALUES (?,?,?,?,?,?,?,?,?,?)
             """.batch(stream_detail.toSeq: _*).apply()

        sql"""
               INSERT INTO loveshow_online_stream_dimension
               (sampling_time,rid,rid_stream_times,isp,isp_stream_times,channel,channel_stream_times,term,term_stream_times,nettype,nettype_stream_times,stream_times,ts_stream_times,total_stream_times)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
             """.batch(stream_dimension.toSeq: _*).apply()

        sql"""
               INSERT INTO loveshow_online_stream_total_dimension
               (sampling_time,rid_stream_times,isp_stream_times,channel_stream_times,term_stream_times,nettype_stream_times,ts_stream_times,total_stream_times)
               VALUES (?,?,?,?,?,?,?,?)
             """.batch(stream_dimension_total.toSeq: _*).apply()

        val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

        offsetRanges.foreach { osr =>
          println(s"${osr.untilOffset} : ${osr.topic} : ${osr.partition} : ${osr.fromOffset}")
          println(partitionIndex.getOrElse(osr.partition,0))
          val offsetRows =
            sql"""
                 update kafka_offsets set offset = ${osr.untilOffset-partitionIndex.getOrElse(osr.partition,0)} where topic = ${osr.topic} and part = ${osr.partition} and offset = ${osr.fromOffset}
              """.update.apply()
          offsetRanges.update(0,OffsetRange.create("streamEvent",0,0,1))
          if (offsetRows != 1) {
            throw new Exception(
              s"""Got $offsetRows rows affected instead of 1 when attempting to update offsets for
                 |${osr.topic} ${osr.partition} ${osr.fromOffset} -> ${osr.untilOffset} Was a partition repeated after a worker failure?
                 |""".stripMargin)
          }
        }
      }
    }
    }
    stream.asInstanceOf[CanCommitOffsets].commitAsync(Array(OffsetRange.create("streamEvent",0,0,0)))
    ssc
  }

  def extractPartitionIndex(map:RDD[Event],current:String)={
    map.mapPartitionsWithIndex {
      (partIdx, iter) => {
        val part_map = scala.collection.mutable.Map[Int, Int]()
        while (iter.hasNext) {
          val offset_name =  partIdx;
          val next = iter.next()
          calendar.setTimeInMillis(next.ts.toLong)
          if (part_map.contains(offset_name) && dateFormat.format(calendar.getTime)>=current) {
            val ele_cnt = part_map(offset_name)
            part_map(offset_name) = ele_cnt + 1
          } else {
            part_map(offset_name) = 0
          }
          next
        }
        part_map.iterator
      }
    }.collect().map(tup => tup._1 -> tup._2).toMap
  }
}
