package com.yuntu.online.stream.structured

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.typesafe.config.ConfigFactory
import com.yuntu.online.stream.bean.Event
import com.yuntu.online.stream.jdbc.SetupJdbc
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.ProcessingTime
import org.apache.spark.sql.{ForeachWriter, Row, SparkSession}
import scalikejdbc.{ConnectionPool, DB, _}

/**
  * Created by Administrator on 2017/6/22 0022.
  */
object StreamTotalDimensionTask {
  val checkpointDirectory = "D:\\chk_streaming"

  val mapper = new ObjectMapper()
  System.getProperty("os.name")
  def main(args: Array[String]): Unit = {
    mapper.registerModule(DefaultScalaModule)
    System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4")

    val conf = ConfigFactory.load
    val jdbcDriver = conf.getString("jdbc.driver")
    val jdbcUrl = conf.getString("jdbc.url")
    val jdbcUser = conf.getString("jdbc.user")
    val jdbcPassword = conf.getString("jdbc.password")

    val spark = SparkSession.builder.appName("Structured_SparkLiveQuality").master("local[3]").getOrCreate()

    import spark.implicits._
    val dataFrame = spark.readStream
      .format("kafka")
      .option("group.id",2)
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "streamEvent")
      .load().selectExpr("CAST(value AS STRING)").as[(String)]

    dataFrame.map { line =>
      mapper.readValue(line, classOf[Event])
    }.toDF().createOrReplaceTempView("streamEvent")

    val stream_detail_total = spark.sql(
      """
        |select
        | CAST(from_unixtime(floor(ts/1000),'yyyy-MM-dd HH:mm:ss') as TIMESTAMP) sampling_time,
        | case when body.type=1 then 1 else 0 end stream_times,
        | channel
        |from streamEvent
      """.stripMargin)
      .withWatermark("sampling_time","10 minutes")
      .groupBy(window($"sampling_time", "1 minutes","1 minutes"),$"channel")
//      .count()
      .agg(sum("stream_times"))
      .withColumn("ctime",col("window.start"))
      .withColumn("etime",col("window.end"))
//      .withColumn("total_stream_times",col("count"))
      .drop("window")
      .coalesce(1)
//    stream_detail_total.printSchema()
    SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)
    stream_detail_total.printSchema()
    val streamingQuery = stream_detail_total
      .writeStream
//      .format("console")
//      .queryName("Structured_SparkLiveQuality")
      .outputMode("update")
      .trigger(ProcessingTime(60*1000))
      .foreach(initWrite)
      .start()
    streamingQuery.awaitTermination()
//    stream_detail.show()
//    spark.sql("select * from Structured_SparkLiveQuality").show()
//    spark.stop()
  }
  def initWrite():ForeachWriter[Row] = {
    val writer = new ForeachWriter[Row] {
      var db:DB = _
      override def open(partitionId: Long, version: Long) = {
        db = DB(ConnectionPool.borrow())
        db.begin()
        println(s"partitionId : ${partitionId}, version:${version}")
        true
      }
      override def process(value: Row) = {
        println(value.toSeq)
            db withinTx { implicit session =>
              sql"""
                   |replace into loveshow_online_stream_test VALUES
                   |(
                   |${value.getAs[String]("isp")},
                   |${value.getAs[Int]("rid")},
                   |${value.getAs[String]("channel")},
                   |${value.getAs[Int]("term")},
                   |${value.getAs[Int]("nettype")},
                   |${value.getAs[Int]("stream_times")},
                   |${value.getAs[String]("ctime")},
                   |${value.getAs[String]("etime")}
                   |)
                """.stripMargin.update.apply()
            }
      }
      override def close(errorOrNull: Throwable) = {
        if(errorOrNull !=null){
          db.rollback()
        }else{
          db.commit()
        }
        db.close()
      }
    }
    writer
  }

}
