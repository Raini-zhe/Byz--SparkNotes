package com.yuntu.online.stream.checkpoint

import java.sql.{Connection, DriverManager, Statement}

import com.fasterxml.jackson.databind.ObjectMapper
import com.yuntu.online.event.Event
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.{SparkConf, TaskContext}
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, KafkaUtils, OffsetRange}
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Created by Administrator on 2017/6/22 0022.
  */
object SparkLiveQuality {
  val checkpointDirectory = "D:\\chk_streaming"

  def main(args: Array[String]): Unit = {
    System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4")
    val context = StreamingContext.getOrCreate(checkpointDirectory, functionToCreateContext _)
    context.start()
    context.awaitTermination()
  }

  // Function to create and setup a new StreamingContext
  def functionToCreateContext(): StreamingContext = {
    val conf = new SparkConf().setAppName("Checkpoint_SparkLiveQuality").setMaster("local[2]").set("spark.streaming.stopGracefullyOnShutdown","true")

    val ssc = new StreamingContext(conf, Seconds(5))

    val topicsSet = Set[String]("test")
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "localhost:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "auto.offset.reset" -> "earliest",
      "enable.auto.commit" -> (false: java.lang.Boolean),
      "group.id" -> "2")

    val dStream = KafkaUtils.createDirectStream[String,String](ssc,
      PreferConsistent,
      Subscribe[String, String](topicsSet, kafkaParams)
    )

//    val dStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topicsSet)
    dStream.foreachRDD{ rdd =>
        val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        for (o <- offsetRanges) {
          println(s"${o.topic} ${o.partition} offsets: ${o.fromOffset} to ${o.untilOffset}")
        }
        rdd.foreachPartition {
          println(TaskContext.get)
          val osr: OffsetRange = offsetRanges(TaskContext.get.partitionId())
          println(s"${osr.fromOffset} -> ${osr.untilOffset}")
          partitionRecords => saveData(partitionRecords)
          //          partitionRecords => partitionRecords.foreach(println)
        }
//      (rdd,time) =>
//        rdd.foreachPartition(partitionIterator =>
//          val partitionId = TaskContext.get.partitionId()
//          val uniqueId = generateUniqueId(time.milliseconds, partitionId)
//          // use this uniqueId to transactionally commit the data in partitionIterator
//        )
    }
    ssc.checkpoint(checkpointDirectory)
    ssc
  }

  def createConnection(): Connection = {
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://localhost:3306/yuntu_bops"
    val username = "root"
    val password = "123555"
    Class.forName(driver)
    val connection: Connection = DriverManager.getConnection(url, username, password)
    connection
  }

  val mapper = new ObjectMapper();

  def saveData(partitionRecords:Iterator[ConsumerRecord[String,String]]): Unit ={
    var connection:Connection = null;
    var stmt:Statement = null;
    try{
      connection = createConnection()
      connection.setAutoCommit(false)
      stmt = connection.createStatement()
      partitionRecords.foreach(record=>{
        val event = mapper.readValue(record.value(),new Event().getClass)
        val sql =
          s"""
             |insert into
             |  loveshow_live_quality(sampling_time,type,version,anchor_id,stream_url,frame_rate,bit_rate,remark)
             |  values(null,'1',${event.getVersion},${event.getUid},${event.getVersion},2,2,'')
           """.stripMargin
        stmt.addBatch(sql)
      })
      stmt.executeBatch()
      connection.commit()
      connection.close()
    }catch {
      case e: Exception => e.printStackTrace()
    }finally {
      if(connection!=null) connection.close()
      if(stmt!=null) stmt.close()
    }
  }
}
