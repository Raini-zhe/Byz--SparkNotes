package com.yuntu.online.stream.transaction


import java.util.Date
import java.util.Calendar
import java.text.SimpleDateFormat

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.common.TopicPartition
import scalikejdbc._
import com.typesafe.config.ConfigFactory
import com.yuntu.online.stream.bean.Event
import com.yuntu.online.stream.jdbc.SetupJdbc
import com.yuntu.online.stream.sql.EventSQL
import org.apache.kafka.clients.consumer.ConsumerRecord

import org.apache.spark.rdd.RDD

import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.{SparkConf, SparkContext, TaskContext}
import org.apache.spark.streaming._
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, KafkaUtils, OffsetRange}
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Assign
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.util.LongAccumulator

/**
  * Created by Administrator on 2017/6/22 0022.
  */
object SparkUserLiveQuality {
  GlobalSettings.loggingSQLAndTime = LoggingSQLAndTimeSettings(
    enabled = true,
    singleLineMode = false,
    printUnprocessedStackTrace = false,
    stackTraceDepth = 15,
    logLevel = 'debug,
    warningEnabled = false,
    warningThresholdMillis = 3000L,
    warningLogLevel = 'warn
  )

  var  dateFormat:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:00")
  val calendar = Calendar.getInstance

  val checkpointDirectory = "D:\\chk_streaming"

  val mapper = new ObjectMapper()

  def main(args: Array[String]): Unit = {
    mapper.registerModule(DefaultScalaModule)
    System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4")
    val conf = ConfigFactory.load
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> conf.getString("kafka.brokers"),
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "1",
      "enable.auto.commit" -> (false: java.lang.Boolean),
      "auto.offset.reset" -> "none"
    )
    val jdbcDriver = conf.getString("jdbc.driver")
    val jdbcUrl = conf.getString("jdbc.url")
    val jdbcUser = conf.getString("jdbc.user")
    val jdbcPassword = conf.getString("jdbc.password")

    val ssc = setupSsc(kafkaParams, jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)()
    ssc.start()
    ssc.awaitTermination()
  }

  def setupSsc(kafkaParams: Map[String, Object],
               jdbcDriver: String,
               jdbcUrl: String,
               jdbcUser: String,
               jdbcPassword: String
              )(): StreamingContext = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("SparkUserLiveQuality")

    val ssc = new StreamingContext(conf, Seconds(60))

    SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)

    // begin from the the offsets committed to the database
    val fromOffsets = DB.readOnly { implicit session =>
      sql"select topic, part, offset from kafka_offsets WHERE topic ='playEvent'".
        map { resultSet =>
          new TopicPartition(resultSet.string(1), resultSet.int(2)) -> resultSet.long(3)
        }.list.apply().toMap
    }

    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      Assign[String, String](fromOffsets.keys.toList, kafkaParams, fromOffsets)
    )

    stream.foreachRDD { rdd => {
      val map = rdd.map {
        record => mapper.readValue(record.value(), classOf[Event])
      }
      val spark = SparkSession.builder().config(conf).getOrCreate()
      import spark.implicits._

      val current = dateFormat.format(new Date)
      map.filter{event =>
        calendar.setTimeInMillis(event.ts.toLong)
        dateFormat.format(calendar.getTime)<current
      }.toDF().cache().createOrReplaceTempView("playEvent")

      val partitionIndex = extractPartitionIndex(map,current)

      println(current)
      println(partitionIndex)
      println(partitionIndex.getOrElse(0,0))
      println(fromOffsets)
      val play_fault = spark.sql(EventSQL.play_fault).rdd.map(row => row.toSeq).collect();
      val online_users = spark.sql(EventSQL.online_users).rdd.map(row => row.toSeq).collect();

      DB.localTx { implicit session =>
        sql"""
               INSERT INTO loveshow_online_play_event (sampling_time,online_users,fault_times,term,location,rid,isp,type,total_online_users) VALUES (?,?,?,?,?,?,?,?,?)
             """.batch(play_fault.toSeq: _*).apply()

        sql"""
               INSERT INTO loveshow_online_users (sampling_time,online_users,type)  VALUES(?,?,?)
             """.batch(online_users.toSeq: _*).apply()
        val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

        offsetRanges.foreach { osr =>
          println(s"${osr.untilOffset} : ${osr.topic} : ${osr.partition} : ${osr.fromOffset}")
          val offsetRows =
            sql"""
                 update kafka_offsets set offset = ${osr.untilOffset-partitionIndex.getOrElse(osr.partition,0)} where topic = ${osr.topic} and part = ${osr.partition} and offset = ${osr.fromOffset}
              """.update.apply()
          if (offsetRows != 1) {
            throw new Exception(
              s"""Got $offsetRows rows affected instead of 1 when attempting to update offsets for
                 |${osr.topic} ${osr.partition} ${osr.fromOffset} -> ${osr.untilOffset} Was a partition repeated after a worker failure?
                 |""".stripMargin)
          }
        }
      }
    }
    }

    //    transactionPerBatch(stream, jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)
    //    transactionPerPartition(stream,jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)
    ssc
  }

  def extractPartitionIndex(map:RDD[Event],current:String)={
    map.mapPartitionsWithIndex {
      (partIdx, iter) => {
        val part_map = scala.collection.mutable.Map[Int, Int]()
        while (iter.hasNext) {
          val offset_name =  partIdx;
          val next = iter.next()
          calendar.setTimeInMillis(next.ts.toLong)
          if (part_map.contains(offset_name) && dateFormat.format(calendar.getTime)>=current) {
            val ele_cnt = part_map(offset_name)
            part_map(offset_name) = ele_cnt + 1
          } else {
            part_map(offset_name) = 0
          }
          next
        }
        part_map.iterator
      }
    }.collect().map(tup => tup._1 -> tup._2).toMap
  }

  def transactionPerBatch(stream: InputDStream[ConsumerRecord[String, String]],
                          jdbcDriver: String,
                          jdbcUrl: String,
                          jdbcUser: String,
                          jdbcPassword: String): Unit = {
    stream.foreachRDD { rdd => {
      val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

      rdd.map(record => record.value())

      val results = rdd.map { record =>
        (record.topic, 1L)
      }.reduceByKey {
        _ + _
      }.collect
      DB.localTx { implicit session =>
        // store metric results
        results.foreach { pair =>
          val (topic, metric) = pair
          val metricRows =
            sql"""
                 update txn_data set metric = metric + ${metric} where topic = ${topic}
              """.update.apply()

          if (metricRows != 1) {
            throw new Exception(
              s"""
                 |Got $metricRows rows affected instead of 1 when attempting to update metrics for $topic
                 |""".stripMargin)
          }
        }
        // store offsets
        offsetRanges.foreach { osr =>
          val offsetRows =
            sql"""
                 update txn_offsets set off = ${osr.untilOffset} where topic = ${osr.topic} and part = ${osr.partition} and off = ${osr.fromOffset}
              """.update.apply()
          if (offsetRows != 1) {
            throw new Exception(
              s"""Got $offsetRows rows affected instead of 1 when attempting to update offsets for
                 |${osr.topic} ${osr.partition} ${osr.fromOffset} -> ${osr.untilOffset} Was a partition repeated after a worker failure?
                 |""".stripMargin)
          }
        }
      }
    }
    }
  }

  def transactionPerPartition(stream: InputDStream[ConsumerRecord[String, String]],
                              jdbcDriver: String,
                              jdbcUrl: String,
                              jdbcUser: String,
                              jdbcPassword: String): Unit = {
    stream.foreachRDD { rdd =>
      // Cast the rdd to an interface that lets us get an array of OffsetRange
      val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

      rdd.foreachPartition { iter =>
        // Note this entire block of code is running in the executors
        SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)

        // index to get the correct offset range for the rdd partition we're working on
        // This is safe because we haven't shuffled or otherwise disrupted partitioning,
        // and the original input rdd partitions were 1:1 with kafka partitions
        val osr: OffsetRange = offsetRanges(TaskContext.get.partitionId)

        // simplest possible "metric", namely a count of messages
        val metric = iter.size

        // localTx is transactional, if metric update or offset update fails, neither will be committed
        DB.localTx { implicit session =>
          // store metric data for this partition
          val metricRows =
            sql"""
                   update txn_data set metric = metric + ${metric} where topic = ${osr.topic}
                """.update.apply()
          if (metricRows != 1) {
            throw new Exception(
              s"""
                 |Got $metricRows rows affected instead of 1 when attempting to update metrics for ${osr.topic} ${osr.partition} ${osr.fromOffset} -> ${osr.untilOffset}
                 |""".stripMargin)
          }

          // store offsets for this partition
          val offsetRows =
            sql"""
                   update txn_offsets set off = ${osr.untilOffset} where topic = ${osr.topic} and part = ${osr.partition} and off = ${osr.fromOffset}
                """.update.apply()
          if (offsetRows != 1) {
            throw new Exception(
              s"""
                 |Got $offsetRows rows affected instead of 1 when attempting to update offsets for ${osr.topic} ${osr.partition} ${osr.fromOffset} -> ${osr.untilOffset}
                 |Was a partition repeated after a worker failure?
                 |""".stripMargin)
          }
        }
      }
    }
  }
}
