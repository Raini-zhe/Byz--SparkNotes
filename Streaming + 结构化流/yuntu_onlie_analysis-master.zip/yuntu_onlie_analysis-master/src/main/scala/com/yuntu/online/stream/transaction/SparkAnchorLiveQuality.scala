package com.yuntu.online.stream.transaction

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.typesafe.config.ConfigFactory
import com.yuntu.online.stream.bean.Event
import com.yuntu.online.stream.jdbc.SetupJdbc
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.DateFormatUtils
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.{SparkConf, TaskContext}
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Assign
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, KafkaUtils, OffsetRange}
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.{Seconds, StreamingContext}
import scalikejdbc._

/**
  * Created by liss on 17-7-2.
  */
object SparkAnchorLiveQuality {
  val mapper = new ObjectMapper()

  def main(args: Array[String]): Unit = {
    mapper.registerModule(DefaultScalaModule)
    System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4")
    val conf = ConfigFactory.load
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> conf.getString("kafka.brokers"),
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "1",
      "enable.auto.commit" -> (false: java.lang.Boolean),
      "auto.offset.reset" -> "none"
    )
    val jdbcDriver = conf.getString("jdbc.driver")
    val jdbcUrl = conf.getString("jdbc.url")
    val jdbcUser = conf.getString("jdbc.user")
    val jdbcPassword = conf.getString("jdbc.password")

    val ssc = setupSsc(kafkaParams, jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)()
    ssc.start()
    ssc.awaitTermination()
  }

  def setupSsc(kafkaParams: Map[String, Object],
               jdbcDriver: String,
               jdbcUrl: String,
               jdbcUser: String,
               jdbcPassword: String
              )(): StreamingContext = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("SparkAnchorLiveQuality")
    val ssc = new StreamingContext(conf, Seconds(60))

    SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)

    // begin from the the offsets committed to the database
    val fromOffsets = DB.readOnly { implicit session =>
      sql"select topic, part, offset from kafka_offsets WHERE topic ='heartbeatEvent'".
        map { resultSet =>
          new TopicPartition(resultSet.string(1), resultSet.int(2)) -> resultSet.long(3)
        }.list.apply().toMap
    }

    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      Assign[String, String](fromOffsets.keys.toList, kafkaParams, fromOffsets)
    )
    transactionPerPartition(stream,jdbcDriver,jdbcUrl,jdbcUser,jdbcPassword)
    ssc
  }

  def transactionPerPartition(stream: InputDStream[ConsumerRecord[String, String]],
                              jdbcDriver: String,
                              jdbcUrl: String,
                              jdbcUser: String,
                              jdbcPassword: String): Unit = {
    stream.foreachRDD { rdd =>

      val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges

      rdd.foreachPartition { iter =>
//        SetupJdbc(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword)

        val osr: OffsetRange = offsetRanges(TaskContext.get.partitionId)

        println(osr)

        val result = iter.map { record =>
          val event = mapper.readValue(record.value(), classOf[Event])
          Seq(DateFormatUtils.format(event.ts.toLong,"yyyy-MM-dd HH:mm:ss"),
            event.uid,
            event.model,
            event.channel,
            event.term,
            event.version,
            event.body.bps,
            event.body.location,
            event.body.rid,
            event.body.isp,
            StringUtils.substringAfterLast(event.body.stream_url,"/"))
        }

        DB.localTx { implicit session =>
          // store metric data for this partition
          val resultRows =
            sql"""
                  INSERT INTO loveshow_online_heartbeat_event (sampling_time,uid,model,channel,term,version,bps,location,rid,isp,streamid) values (?,?,?,?,?,?,?,?,?,?,?)
                """.batch(result.toSeq: _*).apply()

          // store offsets for this partition
          val offsetRows =
            sql"""
                   update kafka_offsets set offset = ${osr.untilOffset} where topic = ${osr.topic} and part = ${osr.partition} and offset = ${osr.fromOffset}
                """.update.apply()
          if (offsetRows != 1) {
            throw new Exception(
              s"""
                 |Got $offsetRows rows affected instead of 1 when attempting to update offsets for ${osr.topic} ${osr.partition} ${osr.fromOffset} -> ${osr.untilOffset}
                 |Was a partition repeated after a worker failure?
                 |""".stripMargin)
          }
        }
      }
    }
  }
}
