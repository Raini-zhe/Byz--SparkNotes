package com.yuntu.online.stream.bean

import com.fasterxml.jackson.annotation.JsonProperty

/**
  * Created by Administrator on 2017/6/27 0027.
  */
@JsonProperty("data")
case class EventBody (
  var `type`:String,

  var subtype:String,

  var location:String,

  /**
    * 推流地址
    */
  var stream_url:String,

  var isp:String,

  var rid:String,

  /**
    * 当前的推流码率，单位kbps，不能低于440.
    */
  var bps:String
)
