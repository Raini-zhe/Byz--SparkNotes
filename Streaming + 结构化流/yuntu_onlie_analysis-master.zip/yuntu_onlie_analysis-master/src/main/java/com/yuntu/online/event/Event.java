package com.yuntu.online.event;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Administrator on 2017/6/22 0022.
 */
public class Event {
    /**
     * 渠道
     */
    private String channel;

    /**
     * 手机型号
     */
    private String model;

    /**
     * WiFi:0, 4G:1
     */
    private String nettype;

    /**
     * 用户终端 0-android 1-ios
     */
    private String term;

    private String token;

    private String ts;

    /**
     * 设备ID
     */
    private String udid;

    private String uid;

    /**
     * app 版本号，VersionCode
     */
    private String version;

    @JsonProperty("data")
    private EventBody body;

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getNettype() {
        return nettype;
    }

    public void setNettype(String nettype) {
        this.nettype = nettype;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTs() {
        return ts;
    }

    public void setTs(String ts) {
        this.ts = ts;
    }

    public String getUdid() {
        return udid;
    }

    public void setUdid(String udid) {
        this.udid = udid;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public EventBody getBody() {
        return body;
    }

    public void setBody(EventBody body) {
        this.body = body;
    }
}
