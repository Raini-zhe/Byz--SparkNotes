package com.yuntu.online.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yuntu.online.event.Event;
import com.yuntu.online.event.EventBody;
import org.apache.commons.lang3.RandomUtils;
import org.apache.kafka.clients.producer.KafkaProducer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

/**
 * Created by Administrator on 2017/6/14 0014.
 */
public class EventProducer extends Thread {
    private Logger LOG = LoggerFactory.getLogger(this.getClass());

    private final KafkaProducer<String, String> producer;
    private final String topic;
    private final Properties props = new Properties();

    public EventProducer(String topic) {
        props.put("bootstrap.servers", "localhost:9092");
        props.put("acks", "all");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("linger.ms", 1);
        props.put("buffer.memory", 33554432);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        producer = new KafkaProducer<String, String>(props);
        this.topic = topic;
    }

    private String[] channels = {"baidu","360","vivo","oppo"};
    private String[] isps = {"移动","联通","电信"};
    private String[] terms = {"0","1"};
    private String[] types = {"0","1","2","3","4"};
    private String[] locations = {"仙桃","广水","深圳","广州","汕头"};
    private String[] uids={"1","2","4","4","5","1","3","6"};

    public Event createEvent(String uid){
        EventBody body = new EventBody();
        body.setIsp(isps[RandomUtils.nextInt(0,3)]);
        body.setLocation(locations[RandomUtils.nextInt(0,5)]);
        body.setType(types[RandomUtils.nextInt(0,5)]);
        body.setStream_url("rtmp://push.live.nagezan.net/vod/11c7989c-8d5d-437e-be84-fdbc1e5d02e3");
        body.setBps(String.valueOf(RandomUtils.nextInt(300,666)));
        body.setRid("666");

        Event event = new Event();
        event.setChannel(channels[RandomUtils.nextInt(0,3)]);
        event.setModel("samsung");
        event.setNettype(terms[RandomUtils.nextInt(0,2)]);
        event.setTerm(terms[RandomUtils.nextInt(0,2)]);
        event.setToken(uid);
        event.setTs(String.valueOf(System.currentTimeMillis()+1000*20));
        event.setUdid("1ea1ea7696f3453779db94e13c4950d0");
        event.setUid(uids[RandomUtils.nextInt(0,8)]);
        event.setVersion("1");
        event.setBody(body);
        return event;
    }

    private static ObjectMapper mapper = new ObjectMapper();

    @Override
    public void run() {
        int uid = 1;
        String message = "";
        while (true) {
            try {
                Event event = createEvent(String.valueOf(uid));
                message = mapper.writeValueAsString(event);
                System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(Long.valueOf(event.getTs())))+" : "+ uid +" : " + event.getBody().getType() +" : "+event.getChannel());
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            producer.send(new ProducerRecord<String, String>(this.topic, String.valueOf(uid), message));
            LOG.info(message);
            uid++;
            try {
                sleep(1000*10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
