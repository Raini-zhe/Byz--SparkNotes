package com.yuntu.online.stream;

import kafka.serializer.StringDecoder;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaPairInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;


import java.util.*;

/**
 * Created by Administrator on 2017/6/22 0022.
 */
public class SparkStream {
    public static void main(String[] args) throws InterruptedException {
//        System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4");
        System.setProperty("hadoop.home.dir", "D:\\hadoop-2.6.4");
        SparkConf conf = new SparkConf().setMaster("local[2]").setAppName("SparkStream");
        JavaStreamingContext context = new JavaStreamingContext(conf, new Duration(1000));

        Map<String, Integer> topicMap = new HashMap<String,Integer>();
        topicMap.put("test1", 1);
//        JavaPairReceiverInputDStream<String, String> messages =
//                KafkaUtils.createStream(context, "localhost:2181", "1", topicMap);
//        messages.print();
        /**
         * DirectStream
         */
        Collection<String> topics  = Arrays.asList("test1");
        Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("zookeeper.connect","localhost:2181");
        kafkaParams.put("bootstrap.servers","localhost:9092");
        kafkaParams.put("auto.offset.reset","largest");
        kafkaParams.put("zookeeper.connection.timeout.ms","30000");
        kafkaParams.put("fetch.message.max.bytes",String.valueOf(1024 * 1024 * 50));
        kafkaParams.put("group.id","2");

        JavaInputDStream<ConsumerRecord<String, String>> directStream = KafkaUtils.createDirectStream(context, LocationStrategies.PreferConsistent(), ConsumerStrategies.<String, String>Subscribe(topics, kafkaParams));

//        JavaPairInputDStream<String, String> directStream = KafkaUtils.createDirectStream(context, String.class, String.class, StringDecoder.class,
//                StringDecoder.class, kafkaParams, topicsSet);
        directStream.print();
        context.start();
        context.awaitTermination();
    }

}
