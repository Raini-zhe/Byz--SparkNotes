//package com.yuntu.online.kafka;
//
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.apache.kafka.clients.consumer.KafkaConsumer;
//
//import java.util.*;
//
///**
// * Created by Administrator on 2017/6/14 0014.
// */
//public class SimpleConsumer extends Thread {
//    private final KafkaConsumer<String, String> consumer;
//    private final String topic;
//
//    public SimpleConsumer(String topic) {
//        this.topic = topic;
//        Properties props = new Properties();
//        props.put("bootstrap.servers", "localhost:9092");
//        props.put("group.id", "test");
//        props.put("enable.auto.commit", "true");
//        props.put("auto.commit.interval.ms", "1000");
//        props.put("session.timeout.ms", "30000");
//        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        consumer = new KafkaConsumer<String, String>(props);
//        consumer.subscribe(KafkaProperties.topic);
//    }
//
//    @Override
//    public void run() {
//        while(true){
//            Map<String,ConsumerRecords<String, String>> records = consumer.poll(100);
//            for (ConsumerRecords<String, String> record : records.values()){
////                System.out.printf("offset = %d, key = %s, value = %s\n",
////                        record.offset(), record.key(), record.value());
//            }
//        }
//    }
//}
