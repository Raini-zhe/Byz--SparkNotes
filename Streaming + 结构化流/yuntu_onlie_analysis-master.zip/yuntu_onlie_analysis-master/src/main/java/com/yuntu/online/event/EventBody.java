package com.yuntu.online.event;

/**
 * Created by Administrator on 2017/6/22 0022.
 */
public class EventBody {

    private String type;

    private String subtype;

    private String location;

    /**
     * 推流地址
     */
    private String stream_url;

    private String isp;

    private String rid;

    /**
     * 当前的推流码率，单位kbps，不能低于440.
     */
    private String bps;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStream_url() {
        return stream_url;
    }

    public void setStream_url(String stream_url) {
        this.stream_url = stream_url;
    }

    public String getIsp() {
        return isp;
    }

    public void setIsp(String isp) {
        this.isp = isp;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getBps() {
        return bps;
    }

    public void setBps(String bps) {
        this.bps = bps;
    }
}
