package com.yuntu.online.kafka;//package com.yuntu.kafka;

/**
 * Created by Administrator on 2017/6/14 0014.
 */
public class KafkaConsumerProducerDemo {
    public static void main(String[] args) {
        EventProducer producerThread = new EventProducer("streamEvent");
        producerThread.start();
//        SimpleConsumer consumerThread = new SimpleConsumer(KafkaProperties.topic);
//        consumerThread.start();
    }
}
