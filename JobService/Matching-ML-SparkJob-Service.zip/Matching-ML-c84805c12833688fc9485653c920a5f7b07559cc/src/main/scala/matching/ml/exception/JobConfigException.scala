package matching.ml.exception

/**
  * Created by stefan on 5/29/17.
  */
class JobConfigException(message: String = "", cause: Throwable = None.orNull) extends Exception(message,cause) {

}
